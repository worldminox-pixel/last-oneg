import React from "react";
import { Plus, Users, ChevronRight } from "lucide-react";
import { Beneficiary } from "../types";
import { initials } from "../utils";

interface QuickTransferProps {
  beneficiaries: Beneficiary[];
  onAddNew: () => void;
  onViewAll: () => void;
  onSelectBeneficiary?: (b: Beneficiary) => void;
  dark: boolean;
}

export function QuickTransfer({
  beneficiaries,
  onAddNew,
  onViewAll,
  onSelectBeneficiary,
  dark,
}: QuickTransferProps) {
  return (
    <div className="px-5 mt-7 select-none">
      <div className="flex items-center justify-between mb-4">
        <h3 className={`font-bold text-base tracking-tight ${dark ? "text-white" : "text-slate-900"}`}>
          Quick Transfer
        </h3>
        <button
          onClick={onViewAll}
          className="text-sky-500 hover:text-sky-400 text-xs font-semibold flex items-center gap-0.5 cursor-pointer"
        >
          View All <ChevronRight size={14} />
        </button>
      </div>
      <div className="flex items-center gap-4 overflow-x-auto pb-2 scrollbar-none">
        {/* Add New recipient button */}
        <button
          onClick={onAddNew}
          className="flex flex-col items-center gap-1.5 shrink-0 group cursor-pointer"
        >
          <div className={`w-14 h-14 rounded-full border-2 border-dashed flex items-center justify-center transition-all ${
            dark
              ? "border-slate-700 hover:border-slate-500 hover:bg-slate-900"
              : "border-slate-300 hover:border-slate-400 hover:bg-slate-100"
          }`}>
            <Plus size={20} className="text-slate-400 group-hover:text-sky-500 transition-colors" />
          </div>
          <span className={`text-[11px] font-medium transition-colors ${
            dark ? "text-slate-400 group-hover:text-white" : "text-slate-500 group-hover:text-slate-900"
          }`}>
            Add New
          </span>
        </button>

        {beneficiaries.length === 0 ? (
          <div className="flex items-center gap-3 py-1.5 px-3 rounded-2xl bg-slate-100/50 dark:bg-slate-800/40 border border-slate-200/50 dark:border-slate-700/30">
            <div className="w-10 h-10 rounded-full bg-slate-200 dark:bg-slate-800 flex items-center justify-center text-slate-400">
              <Users size={16} />
            </div>
            <p className={`text-xs ${dark ? "text-slate-400" : "text-slate-500"} leading-tight`}>
              No saved payees.<br />Add some above!
            </p>
          </div>
        ) : (
          beneficiaries.map((b) => (
            <button
              key={b.id}
              onClick={() => onSelectBeneficiary?.(b)}
              className="flex flex-col items-center gap-1.5 shrink-0 group cursor-pointer"
              title={`Send money to ${b.name}`}
            >
              <div
                className="w-14 h-14 rounded-full flex items-center justify-center text-white font-bold text-sm shadow-md transition-transform group-hover:scale-105"
                style={{ background: "linear-gradient(135deg, #3DC4F5, #0B6FB0)" }}
              >
                {initials(b.name)}
              </div>
              <span className={`text-[11px] font-medium truncate w-14 text-center transition-colors ${
                dark ? "text-slate-300 group-hover:text-white" : "text-slate-600 group-hover:text-slate-900"
              }`}>
                {b.name.split(" ")[0]}
              </span>
            </button>
          ))
        )}
      </div>
    </div>
  );
}
