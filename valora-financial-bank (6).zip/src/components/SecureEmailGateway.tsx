import React, { useState, useEffect } from "react";
import { Mail, ShieldCheck, Copy, Check, Bell, ChevronDown, ChevronUp, Clock, AlertCircle } from "lucide-react";

interface SecureEmailGatewayProps {
  emailData: {
    email: string;
    otp: string;
    subject: string;
    body: string;
    sentAt: string;
    txId: string;
  } | null;
  dark: boolean;
}

export function SecureEmailGateway({ emailData, dark }: SecureEmailGatewayProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [hasNew, setHasNew] = useState(false);
  const [copied, setCopied] = useState(false);

  // Sound cue or alert ping on email receipt
  useEffect(() => {
    if (emailData) {
      setHasNew(true);
      setIsOpen(true); // Open automatically on dispatch to guide user
      const timer = setTimeout(() => setHasNew(false), 5000);
      return () => clearTimeout(timer);
    }
  }, [emailData]);

  if (!emailData) return null;

  const handleCopy = () => {
    navigator.clipboard.writeText(emailData.otp);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className={`fixed bottom-24 right-5 md:right-8 z-40 max-w-sm w-[90vw] rounded-[2rem] border shadow-2xl transition-all duration-500 overflow-hidden ${
      isOpen ? "translate-y-0 opacity-100 scale-100" : "translate-y-2 opacity-95 scale-95"
    } ${
      hasNew ? "ring-4 ring-sky-500/30 animate-pulse" : ""
    } ${
      dark ? "bg-slate-950 border-slate-800 text-white" : "bg-slate-900 border-slate-700 text-slate-100"
    }`}>
      
      {/* Header bar */}
      <div 
        onClick={() => setIsOpen(!isOpen)}
        className="px-5 py-4 flex items-center justify-between cursor-pointer select-none bg-slate-900 hover:bg-slate-850/80 transition-colors"
      >
        <div className="flex items-center gap-2.5">
          <div className="relative">
            <Mail size={16} className="text-sky-400" />
            <span className="absolute -top-1 -right-1 w-2 h-2 rounded-full bg-emerald-500 inline-block" />
          </div>
          <div>
            <span className="text-[10px] font-black uppercase tracking-widest text-sky-400 font-mono">
              Confidential Secure Mailbox
            </span>
            <p className="text-[9px] text-slate-400 font-bold">Encrypted Node: us-la-ssl (Los Angeles Branch)</p>
          </div>
        </div>
        <div className="flex items-center gap-2 bg-slate-950/40 px-2 py-1 rounded-lg">
          <span className="text-[9px] font-bold text-emerald-400 font-mono animate-pulse">
            NEW MSG
          </span>
          {isOpen ? <ChevronDown size={14} className="text-slate-400" /> : <ChevronUp size={14} className="text-slate-400" />}
        </div>
      </div>

      {isOpen && (
        <div className="p-5 space-y-4 max-h-[360px] overflow-y-auto scrollbar-thin scrollbar-thumb-slate-800">
          
          {/* Notification Alert Info */}
          <div className="p-3 bg-sky-500/10 border border-sky-500/20 rounded-2xl flex gap-2">
            <AlertCircle size={15} className="text-sky-400 shrink-0 mt-0.5" />
            <p className="text-[10px] text-sky-200/90 leading-relaxed font-semibold">
              Valora Secure Core dispatched this digital transmission. This represents the official encrypted client-bound email.
            </p>
          </div>

          {/* Email Headers container */}
          <div className="text-[10.5px] font-semibold text-slate-400 space-y-1.5 border-b border-slate-800/80 pb-3">
            <p>
              <strong className="text-slate-300">From:</strong> Valora Trust Security &lt;<span className="text-sky-400 hover:underline cursor-pointer">security@valorafinancialbank.com</span>&gt;
            </p>
            <p>
              <strong className="text-slate-300">To:</strong> {emailData.email}
            </p>
            <p>
              <strong className="text-slate-300">Subject:</strong> <span className="text-amber-500 font-bold">{emailData.subject}</span>
            </p>
            <p className="text-[9px] font-mono text-slate-500 flex items-center gap-1 mt-1">
              <Clock size={10} /> Dispatched US ledger time: {new Date(emailData.sentAt).toLocaleTimeString("en-US", { timeZone: "America/New_York" })}
            </p>
          </div>

          {/* Email Body template */}
          <div className="bg-slate-900/60 p-4 rounded-2.5xl text-xs font-medium space-y-4 text-slate-300 whitespace-pre-wrap leading-relaxed border border-slate-800/50">
            <p>Dear Customer,</p>
            <p>A transaction request was made on your Valora Financial Bank account.</p>
            
            {/* Highly highlighted code box */}
            <div className="flex items-center justify-between p-4 bg-slate-950 border border-sky-500/20 rounded-2xl my-3">
              <div>
                <p className="text-[9px] font-bold text-slate-400 uppercase tracking-widest mb-1">
                  Verification Code
                </p>
                <span className="text-2xl font-black font-mono tracking-[0.25em] text-emerald-400">
                  {emailData.otp}
                </span>
              </div>
              <button
                onClick={handleCopy}
                className={`py-2 px-3 rounded-xl text-[10px] uppercase font-black transition-all cursor-pointer flex items-center gap-1.5 ${
                  copied
                    ? "bg-emerald-500 text-slate-950 shadow-sm"
                    : "bg-slate-850 hover:bg-slate-800 text-sky-400 border border-sky-500/10"
                }`}
              >
                {copied ? (
                  <>
                    <Check size={11} className="stroke-[3]" />
                    <span>COPIED</span>
                  </>
                ) : (
                  <>
                    <Copy size={11} />
                    <span>COPY OTP</span>
                  </>
                )}
              </button>
            </div>

            <p className="text-[11px] text-amber-500 font-bold">This code will expire in 10 minutes.</p>
            <p className="text-[10px] text-slate-400">If you did not request this transaction, please contact support immediately.</p>
            <p className="text-[10.5px] font-bold text-slate-200 border-t border-slate-800/80 pt-2.5">
              Valora Financial Bank Security Team
            </p>
          </div>

          {/* Footer signature check */}
          <div className="flex items-center gap-1.5 justify-center text-[9px] font-bold text-slate-500 uppercase tracking-widest mt-1">
            <ShieldCheck size={11} className="text-emerald-500" />
            <span>ECC 256 SHA-HASH SIGNATURE VALIDATED</span>
          </div>
        </div>
      )}
    </div>
  );
}
