import React, { useState } from "react";
import { KeyRound, CreditCard, Lock, ArrowRight, Eye, EyeOff } from "lucide-react";
import { UserProfile } from "../types";
import { PrimaryButton } from "./PrimaryButton";
import { ValoraLogo } from "./ValoraLogo";

interface LoginScreenProps {
  users: UserProfile[];
  onLogin: (userId: string) => void;
  onEnterAdmin: () => void;
  dark: boolean;
}

export function LoginScreen({ users, onLogin, onEnterAdmin, dark }: LoginScreenProps) {
  // Single unified login form state
  const [accountNumber, setAccountNumber] = useState("");
  const [password, setPassword] = useState("");
  const [pin, setPIN] = useState("");
  const [error, setError] = useState("");
  const [isLoggingIn, setIsLoggingIn] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  const [showPin, setShowPin] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    const acct = accountNumber.trim();
    const pwd = password.trim();
    const securityPin = pin.trim();

    if (!acct) {
      setError("Please enter your 10-digit account number.");
      return;
    }
    if (!pwd) {
      setError("Please enter your account password.");
      return;
    }
    if (securityPin.length < 4) {
      setError("Please enter your 4-digit security PIN.");
      return;
    }

    setIsLoggingIn(true);
    setError("");

    try {
      const response = await fetch("/api/auth/login", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          accountNumber: acct,
          password: pwd,
          pin: securityPin,
        }),
      });

      const data = await response.json();

      if (response.ok && data.success) {
        localStorage.setItem("session_user_id", data.userId || "ADMIN");
        localStorage.setItem("session_is_admin", String(data.isAdminView));

        setAccountNumber("");
        setPassword("");
        setPIN("");
        if (data.isAdminView) {
          onEnterAdmin();
        } else {
          onLogin(data.userId);
        }
      } else {
        const errorMsg = data.error || "Access Denied! Invalid credentials. Verify Account Number, Password, and security PIN.";
        setError(errorMsg);
        console.warn("[LOGIN_API_FAIL]", errorMsg);
      }
    } catch (err: any) {
      setError("Portal Connection Timeout. Please check your network linkage or contact support.");
      console.error("[LOGIN_NETWORK_ERROR]", err);
    } finally {
      setIsLoggingIn(false);
    }
  };

  const handlePinChange = (val: string) => {
    const sanitized = val.replace(/\D/g, "").slice(0, 4);
    setPIN(sanitized);
    setError("");
  };

  return (
    <div className="flex flex-col justify-between min-h-[82vh] w-full max-w-md mx-auto p-4 animate-[fadeIn_0.35s_ease-out]">
      {/* Brand Header */}
      <div className="text-center mt-6 mb-8 flex flex-col items-center justify-center">
        <ValoraLogo dark={dark} className="h-16" />
        <p className="text-[10px] text-emerald-500 font-extrabold mt-3 uppercase tracking-[0.22em] font-mono">
          Private Wealth Custody
        </p>
      </div>

      {/* Unified Security Entrance Card */}
      <div className={`p-6 md:p-8 rounded-[2.5rem] border shadow-2xl transition-all duration-300 ${
        dark ? "bg-slate-900 border-slate-800 text-white" : "bg-white border-slate-200 text-slate-900"
      }`}>
        <div className="flex items-center gap-3 mb-6 border-b border-slate-500/10 pb-4">
          <div className="p-2 rounded-xl bg-brand-red/10 text-brand-red">
            <Lock size={18} />
          </div>
          <div>
            <h2 className="font-extrabold text-base tracking-tight">
              Sovereign Secure Portal
            </h2>
            <p className="text-[10px] text-slate-400 font-medium">
              Authenticate via standard biometric or keycode protocols
            </p>
          </div>
        </div>

        <form onSubmit={handleSubmit} className="space-y-5">
          {/* Account Number Input */}
          <div className="space-y-1.5">
            <label className={`block text-[9px] font-black uppercase tracking-widest ${
              dark ? "text-slate-400" : "text-slate-500"
            }`}>
              Account Number
            </label>
            <input
              type="text"
              placeholder="e.g. 2370214698"
              maxLength={15}
              value={accountNumber}
              onChange={(e) => {
                setAccountNumber(e.target.value.replace(/\D/g, ""));
                setError("");
              }}
              className={`w-full p-3.5 rounded-2xl outline-none text-xs font-bold font-mono transition-all border ${
                dark
                  ? "bg-slate-950 border-slate-850 text-white focus:border-brand-red focus:ring-1 focus:ring-brand-red/30"
                  : "bg-slate-50 border-slate-200 text-slate-900 focus:border-brand-red focus:bg-white focus:ring-1 focus:ring-brand-red/20"
              }`}
            />
          </div>

          {/* Password Input */}
          <div className="space-y-1.5">
            <label className={`block text-[9px] font-black uppercase tracking-widest ${
              dark ? "text-slate-400" : "text-slate-500"
            }`}>
              Portal Password
            </label>
            <div className="relative">
              <input
                type={showPassword ? "text" : "password"}
                placeholder="••••••••••••"
                value={password}
                onChange={(e) => {
                  setPassword(e.target.value);
                  setError("");
                }}
                className={`w-full p-3.5 pr-12 rounded-2xl outline-none text-xs font-bold transition-all border ${
                  dark
                    ? "bg-slate-950 border-slate-850 text-white focus:border-brand-red focus:ring-1 focus:ring-brand-red/30"
                    : "bg-slate-50 border-slate-200 text-slate-900 focus:border-brand-red focus:bg-white focus:ring-1 focus:ring-brand-red/20"
                }`}
              />
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="absolute right-4 top-1/2 -translate-y-1/2 p-1 rounded-lg text-slate-400 hover:text-brand-red hover:bg-brand-red/10 transition-colors"
                title={showPassword ? "Hide password" : "Show password"}
              >
                {showPassword ? <EyeOff size={16} /> : <Eye size={16} />}
              </button>
            </div>
          </div>

          {/* Secure 4-Digit PIN Input */}
          <div className="space-y-1.5">
            <label className={`block text-[9px] font-black uppercase tracking-widest ${
              dark ? "text-slate-400" : "text-slate-500"
            }`}>
              Security PIN
            </label>
            <div className="relative">
              <KeyRound className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 dark:text-slate-600 w-4 h-4" />
              <input
                type={showPin ? "text" : "password"}
                placeholder="••••"
                pattern="[0-9]*"
                inputMode="numeric"
                maxLength={4}
                value={pin}
                onChange={(e) => handlePinChange(e.target.value)}
                className={`w-full p-3.5 pl-12 pr-12 rounded-2xl outline-none text-center font-mono text-base tracking-[0.8em] font-black transition-all border ${
                  dark
                    ? "bg-slate-950 border-slate-850 text-white placeholder:text-slate-800 focus:border-brand-red focus:ring-1 focus:ring-brand-red/30"
                    : "bg-slate-50 border-slate-200 text-slate-900 placeholder:text-slate-400 focus:border-brand-red focus:ring-1 focus:ring-brand-red/20"
                }`}
              />
              <button
                type="button"
                onClick={() => setShowPin(!showPin)}
                className="absolute right-4 top-1/2 -translate-y-1/2 p-1 rounded-lg text-slate-400 hover:text-brand-red hover:bg-brand-red/10 transition-colors"
                title={showPin ? "Hide PIN" : "Show PIN"}
              >
                {showPin ? <EyeOff size={16} /> : <Eye size={16} />}
              </button>
            </div>
          </div>

          {error && (
            <div className="p-3.5 rounded-xl bg-rose-500/10 border border-rose-500/20 text-rose-600 dark:text-rose-400 text-[10.5px] font-bold leading-relaxed animate-[shake_0.4s_ease-in-out]">
              ⚠️ {error}
            </div>
          )}

          <button
            type="submit"
            disabled={isLoggingIn}
            className="w-full py-4 px-6 rounded-2xl bg-brand-red hover:bg-[#A93226] disabled:opacity-50 active:scale-[0.98] text-white font-black text-xs uppercase tracking-wider transition-all flex items-center justify-center gap-2 cursor-pointer shadow-lg shadow-brand-red/15"
          >
            <span>{isLoggingIn ? "Authorizing Entry..." : "Unlock Asset Vault"}</span>
            {!isLoggingIn && <ArrowRight size={14} className="stroke-[2.5]" />}
          </button>
        </form>
      </div>

      {/* Bottom Legal Copyright */}
      <div className="text-center mt-8 mb-4">
        <p className="text-[9px] text-slate-500 font-bold uppercase tracking-widest font-mono">
          © {new Date().getFullYear()} Valora Financial Bank LLC &middot; Los Angeles, CA Office Branch &middot; FDIC & SEC ID 4930-VFB
        </p>
      </div>
    </div>
  );
}
