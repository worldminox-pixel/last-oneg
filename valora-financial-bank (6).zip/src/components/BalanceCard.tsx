import React, { useState, useRef } from "react";
import { Eye, EyeOff, Landmark, TrendingUp, Coins } from "lucide-react";
import { UserProfile } from "../types";
import { fmtMoney, fmtDateTime } from "../utils";

interface BalanceCardProps {
  user: UserProfile;
  balanceVisible: boolean;
  setBalanceVisible: (val: boolean | ((prev: boolean) => boolean)) => void;
}

export function BalanceCard({
  user,
  balanceVisible,
  setBalanceVisible,
}: BalanceCardProps) {
  const [activeIndex, setActiveIndex] = useState(0);
  const startX = useRef<number | null>(null);
  const [drag, setDrag] = useState(0);

  const onStart = (clientX: number) => {
    startX.current = clientX;
  };

  const onMove = (clientX: number) => {
    if (startX.current !== null) {
      setDrag(clientX - startX.current);
    }
  };

  const btcValueInUsd = 68500;
  const userBtcBalance = user.bitcoinBalance ?? 0;
  const btcUsdValuation = Math.round(userBtcBalance * btcValueInUsd * 100) / 100;
  const userInvestmentBalance = user.investmentBalance ?? 0;

  const accounts = user.enabledAccounts || ["checking", "investment", "bitcoin"];

  const cards = [];

  if (accounts.includes("checking")) {
    cards.push({
      id: "checking",
      label: "Premium Liquid Wallet",
      balance: user.balance,
      number: user.accountNumber,
      gradient: ["#0284c7", "#0369a1"],
      bank: "VALORA FINANCIAL BANK",
      tag: "Checking Route",
      isCrypto: false,
      isInvestment: false,
      statusTag: user.checkingFrozen ? "Frozen Liquid" : "Active Liquid"
    });
  }

  if (accounts.includes("bitcoin")) {
    cards.push({
      id: "bitcoin",
      label: "Sovereign Bitcoin Cold Vault",
      balance: btcUsdValuation,
      number: "BTC-SOV-" + user.accountNumber.slice(-4),
      gradient: ["#f59e0b", "#c2410c"], // Golden Orange / Amber-rust gradient for Bitcoin
      bank: "VALORA DECENTRALIZED COLD STORAGE",
      tag: "Bitcoin Cold Wallet",
      isCrypto: true,
      isInvestment: false,
      cryptoBalance: userBtcBalance.toFixed(4),
      statusTag: user.bitcoinFrozen ? "Frozen SegWit Ledger" : "Cold SegWit Ledger"
    });
  }

  if (accounts.includes("investment")) {
    cards.push({
      id: "investments",
      label: "Wealth Investment Portfolio",
      balance: userInvestmentBalance,
      number: "INV-PORT-" + user.accountNumber.slice(-4),
      gradient: ["#0d9488", "#0f766e"], // Emerald/Teal premium gradient for investment vaults
      bank: "VALORA PRIVATE ASSET MANAGEMENT",
      tag: "Investment Account",
      isCrypto: false,
      isInvestment: true,
      statusTag: user.investmentFrozen ? "Frozen Yield Balance" : "Sovereign Yield Portfolio"
    });
  }

  // Handle boundary errors nicely if accounts get reconfigured live
  const safeActiveIndex = Math.min(activeIndex, Math.max(0, cards.length - 1));

  const onEnd = () => {
    if (startX.current !== null) {
      if (drag < -60 && safeActiveIndex < cards.length - 1) {
        setActiveIndex((prev) => Math.min(prev + 1, cards.length - 1));
      } else if (drag > 60 && safeActiveIndex > 0) {
        setActiveIndex((prev) => Math.max(prev - 1, 0));
      }
      setDrag(0);
      startX.current = null;
    }
  };

  const currentCard = cards[safeActiveIndex];

  return (
    <div className="px-5">
      <div
        className="overflow-hidden touch-pan-y cursor-grab active:cursor-grabbing select-none"
        onTouchStart={(e) => onStart(e.touches[0].clientX)}
        onTouchMove={(e) => onMove(e.touches[0].clientX)}
        onTouchEnd={onEnd}
        onMouseDown={(e) => onStart(e.clientX)}
        onMouseMove={(e) => startX.current !== null && onMove(e.clientX)}
        onMouseUp={onEnd}
        onMouseLeave={onEnd}
      >
        <div
          className="flex transition-transform ease-out"
          style={{
            transform: `translateX(calc(${-safeActiveIndex * 100}% + ${drag}px))`,
            transitionDuration: startX.current !== null ? "0ms" : "250ms",
          }}
        >
          {cards.map((c) => (
            <div key={c.id} className="w-full shrink-0">
              <div
                className="relative rounded-3xl p-6 overflow-hidden shadow-xl"
                style={{ background: `linear-gradient(135deg, ${c.gradient[0]}, ${c.gradient[1]})` }}
              >
                {/* Modern visual background grids */}
                <div className="absolute -top-6 -right-10 w-40 h-40 rounded-full bg-white/10 pointer-events-none" />
                <div className="absolute -bottom-10 -left-10 w-32 h-32 rounded-full bg-white/10 pointer-events-none" />

                <div className="relative flex justify-between items-start z-10">
                  <div>
                    <span className="text-white/60 text-[9px] uppercase tracking-widest font-black flex items-center gap-1">
                      {c.isCrypto ? <Coins size={10} /> : <Landmark size={10} />} {c.bank}
                    </span>
                    <p className="text-white text-base font-extrabold mt-1 tracking-tight">{user.name}</p>
                  </div>
                  <div className="text-right">
                    <p className="text-white/80 text-[10px] uppercase font-mono tracking-wider bg-white/15 px-2 py-0.5 rounded-full inline-block">
                      {c.tag}
                    </p>
                    <p className="text-white/95 text-xs tracking-widest mt-1.5 font-mono">
                      Acc: ••••{c.number.slice(-4)}
                    </p>
                  </div>
                </div>

                <div className="relative text-center mt-7 z-10">
                  <p className="text-white/70 text-[10.5px] uppercase tracking-wider font-extrabold">
                    {c.isCrypto ? "Vault Crypto Balance" : "Available Funds"}
                  </p>
                  <div className="flex flex-col items-center justify-center mt-1">
                    <div className="flex items-center justify-center gap-2">
                       <p className="text-white text-3xl font-black tracking-tight font-mono">
                        {balanceVisible 
                          ? (c.isCrypto ? `${c.cryptoBalance} BTC` : fmtMoney(c.balance)) 
                          : "••••••"}
                      </p>
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          setBalanceVisible((v) => !v);
                        }}
                        className="text-white/70 hover:text-white p-1 transition-colors cursor-pointer"
                        title={balanceVisible ? "Hide Wealth Display" : "Show Wealth Display"}
                      >
                        {balanceVisible ? <Eye size={18} /> : <EyeOff size={18} />}
                      </button>
                    </div>
                    {c.isCrypto && balanceVisible && (
                      <p className="text-white/85 text-[10px] font-semibold font-mono mt-1 bg-black/20 px-2 rounded-full py-0.5">
                        Valuation: {fmtMoney(c.balance)} USD &bull; @ $68.5k
                      </p>
                    )}
                  </div>
                </div>

                <div className="relative flex justify-between items-center mt-7 z-10">
                  <p className="text-white/95 text-[10px] font-bold flex items-center gap-1.5 bg-black/10 px-2.5 py-1 rounded-full">
                    <span className={`w-1.5 h-1.5 rounded-full inline-block ${
                      c.statusTag.toLowerCase().includes("frozen") ? "bg-amber-500 animate-pulse" : "bg-emerald-400 animate-pulse"
                    }`} /> {c.statusTag}
                  </p>
                  <p className="text-white/70 text-[10px] font-mono">
                    Acc Number: {c.number}
                  </p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Dots controller */}
      <div className="flex justify-center gap-1.5 mt-3.5">
        {cards.map((_, i) => (
          <button
            key={i}
            onClick={() => setActiveIndex(i)}
            className={`h-1.5 rounded-full transition-all cursor-pointer ${
              i === safeActiveIndex ? "w-4 bg-teal-400" : "bg-slate-300 w-1.5"
            }`}
          />
        ))}
      </div>
    </div>
  );
}
