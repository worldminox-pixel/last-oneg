import React from "react";
import { 
  X, Home as HomeIcon, TrendingUp, CreditCard, Send, Globe, 
  Download, Landmark, Award, Settings as SettingsIcon, HelpCircle, 
  LogOut, ShieldAlert, BadgeInfo, CheckCircle2, Receipt
} from "lucide-react";
import { UserProfile } from "../types";
import { initials } from "../utils";

interface BankingMenuProps {
  open: boolean;
  onClose: () => void;
  user: UserProfile;
  dark: boolean;
  onSelectTab: (tab: string) => void;
  onOpenTopUp: () => void;
  onOpenLoan: () => void;
  onOpenIrsRefund: () => void;
  onSignOut: () => void;
}

export function BankingMenu({
  open,
  onClose,
  user,
  dark,
  onSelectTab,
  onOpenTopUp,
  onOpenLoan,
  onOpenIrsRefund,
  onSignOut,
}: BankingMenuProps) {
  if (!open) return null;

  const menuItems = [
    {
      id: "home",
      label: "Home",
      icon: HomeIcon,
      bgColor: "bg-[#0ea5e9]/10 hover:bg-[#0ea5e9]/20 text-[#0ea5e9] dark:bg-sky-500/10 dark:text-sky-400",
      iconBg: "bg-gradient-to-tr from-sky-400 to-sky-500 text-white shadow-sm shadow-sky-500/20",
      action: () => {
        onSelectTab("home");
        onClose();
      }
    },
    {
      id: "activity",
      label: "Activity",
      icon: TrendingUp,
      bgColor: "bg-[#10b981]/10 hover:bg-[#10b981]/20 text-[#10b981] dark:bg-emerald-500/10 dark:text-emerald-400",
      iconBg: "bg-gradient-to-tr from-emerald-400 to-emerald-500 text-white shadow-sm shadow-emerald-500/20",
      action: () => {
        onSelectTab("activity");
        onClose();
      }
    },
    {
      id: "cards",
      label: "Cards",
      icon: CreditCard,
      bgColor: "bg-[#0ea5e9]/10 hover:bg-[#0ea5e9]/20 text-[#0ea5e9] dark:bg-sky-500/10 dark:text-sky-400",
      iconBg: "bg-gradient-to-tr from-sky-400 to-sky-500 text-white shadow-sm shadow-sky-500/20",
      action: () => {
        onSelectTab("cards");
        onClose();
      }
    },
    {
      id: "transfer",
      label: "Transfer",
      icon: Send,
      bgColor: "bg-[#10b981]/10 hover:bg-[#10b981]/20 text-[#10b981] dark:bg-emerald-500/10 dark:text-emerald-400",
      iconBg: "bg-gradient-to-tr from-emerald-400 to-emerald-500 text-white shadow-sm shadow-emerald-500/20",
      action: () => {
        onSelectTab("transfer");
        onClose();
      }
    },
    {
      id: "intl-wire",
      label: "Int'l Wire",
      icon: Globe,
      bgColor: "bg-[#10b981]/10 hover:bg-[#10b981]/20 text-[#10b981] dark:bg-emerald-500/10 dark:text-emerald-400",
      iconBg: "bg-gradient-to-tr from-emerald-400 to-emerald-500 text-white shadow-sm shadow-emerald-500/20",
      action: () => {
        onSelectTab("transfer");
        // We will trigger a nice window alert confirming wire connection
        setTimeout(() => {
          alert("Valora Private Banking Secure Wire Gateway has been established. Funds destination will clear instantly through Sovereign US clearing nodes.");
        }, 150);
        onClose();
      }
    },
    {
      id: "paybills",
      label: "Pay Bills",
      icon: Receipt,
      bgColor: "bg-[#10b981]/10 hover:bg-[#10b981]/20 text-[#10b981] dark:bg-[#10b981]/10 dark:text-emerald-400",
      iconBg: "bg-gradient-to-tr from-emerald-400 to-emerald-500 text-white shadow-sm shadow-emerald-500/20",
      action: () => {
        onSelectTab("paybills");
        onClose();
      }
    },
    {
      id: "deposit",
      label: "Deposit",
      icon: Download,
      bgColor: "bg-[#0ea5e9]/10 hover:bg-[#0ea5e9]/20 text-[#0ea5e9] dark:bg-sky-500/10 dark:text-sky-400",
      iconBg: "bg-gradient-to-tr from-sky-400 to-sky-500 text-white shadow-sm shadow-sky-500/20",
      action: () => {
        onClose();
        onOpenTopUp();
      }
    },
    {
      id: "loan",
      label: "Loan",
      icon: Landmark,
      bgColor: "bg-[#10b981]/10 hover:bg-[#10b981]/20 text-[#10b981] dark:bg-emerald-500/10 dark:text-emerald-400",
      iconBg: "bg-gradient-to-tr from-emerald-400 to-emerald-500 text-white shadow-sm shadow-emerald-500/20",
      action: () => {
        onClose();
        onOpenLoan();
      }
    },
    {
      id: "irs-refund",
      label: "IRS Refund",
      icon: Award,
      bgColor: "bg-[#0ea5e9]/10 hover:bg-[#0ea5e9]/20 text-[#0ea5e9] dark:bg-sky-500/10 dark:text-sky-400",
      iconBg: "bg-gradient-to-tr from-sky-400 to-sky-500 text-white shadow-sm shadow-sky-500/20",
      action: () => {
        onClose();
        onOpenIrsRefund();
      }
    },
    {
      id: "settings",
      label: "Settings",
      icon: SettingsIcon,
      bgColor: "bg-[#0ea5e9]/10 hover:bg-[#0ea5e9]/20 text-[#0ea5e9] dark:bg-sky-500/10 dark:text-sky-400",
      iconBg: "bg-gradient-to-tr from-sky-400 to-sky-500 text-white shadow-sm shadow-sky-500/20",
      action: () => {
        onSelectTab("profile");
        onClose();
      }
    },
    {
      id: "logout",
      label: "Logout",
      icon: LogOut,
      bgColor: "bg-rose-500/10 hover:bg-rose-500/20 text-rose-500 dark:bg-rose-500/10 dark:text-rose-400",
      iconBg: "bg-gradient-to-tr from-rose-400 to-rose-500 text-white shadow-sm shadow-rose-500/20",
      action: () => {
        onClose();
        onSignOut();
      }
    }
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm animate-[fadeIn_0.2s_ease-out]">
      <div 
        className={`w-full max-w-sm rounded-[2rem] border overflow-hidden p-6 relative transition-all shadow-2xl ${
          dark ? "bg-slate-900 border-slate-800 text-white" : "bg-white border-slate-100 text-slate-900"
        }`}
      >
        {/* Modal close icon */}
        <button 
          onClick={onClose}
          className={`absolute top-5 right-5 p-1.5 rounded-full transition-colors cursor-pointer ${
            dark ? "hover:bg-slate-800 text-slate-400 hover:text-white" : "hover:bg-slate-100 text-slate-500 hover:text-slate-900"
          }`}
        >
          <X size={18} />
        </button>

        {/* Top Header Section with User details matching the photograph closely */}
        <div className="flex items-center gap-3.5 pb-5 border-b border-slate-150 dark:border-slate-800/80 mb-6">
          <div className="relative">
            {user.avatarUrl ? (
              <img 
                src={user.avatarUrl} 
                alt={user.name} 
                className="w-14 h-14 rounded-full object-cover border-2 border-sky-400/85"
                referrerPolicy="no-referrer"
              />
            ) : (
              <div 
                className="w-14 h-14 rounded-full flex items-center justify-center text-white font-extrabold text-base shadow-md"
                style={{ background: "linear-gradient(135deg, #0ea5e9, #0284c7)" }}
              >
                {initials(user.name)}
              </div>
            )}
            {/* Green Badge online status */}
            <span className="absolute bottom-0 right-0 w-3.5 h-3.5 bg-emerald-500 border-2 border-white dark:border-slate-900 rounded-full" />
          </div>

          <div className="min-w-0 pr-6">
            <h3 className="font-extrabold text-lg leading-tight tracking-tight text-ellipsis overflow-hidden whitespace-nowrap">
              {user.name}
            </h3>
            <p className={`text-xs font-medium tracking-wide mt-0.5 ${dark ? "text-slate-400" : "text-slate-500"}`}>
              Account: {user.accountNumber}
            </p>
            {/* Verified badge */}
            <div className="inline-flex items-center gap-1 mt-1 bg-emerald-500/10 text-emerald-500 dark:text-emerald-400 px-2 py-0.5 rounded-full text-[10px] font-bold">
              <CheckCircle2 size={10} className="stroke-[3]" />
              <span>Verified Account</span>
            </div>
          </div>
        </div>

        {/* Banking Menu title text matching photograph */}
        <div className="text-center mb-6">
          <h2 className="text-xl font-black uppercase tracking-tight">Banking Menu</h2>
          <p className={`text-xs font-semibold tracking-wide ${dark ? "text-slate-400" : "text-slate-500"}`}>
            Select an option to continue
          </p>
        </div>

        {/* Menu Grid section with highly-styled responsive touch targets */}
        <div className="grid grid-cols-3 gap-2.5 max-h-[50vh] overflow-y-auto pr-0.5 scrollbar-thin">
          {menuItems.map((item) => {
            const IconComponent = item.icon;
            return (
              <button
                key={item.id}
                onClick={item.action}
                className={`flex flex-col items-center justify-center p-3 rounded-2xl cursor-pointer transition-all duration-150 active:scale-95 group border-transparent ${item.bgColor}`}
                style={{ contentVisibility: "auto" }}
              >
                <div className={`w-11 h-11 rounded-2xl flex items-center justify-center mb-1.5 transition-transform group-hover:scale-110 ${item.iconBg}`}>
                  <IconComponent size={20} className="stroke-[2.5]" />
                </div>
                <span className="text-[10px] font-black tracking-wide text-center uppercase leading-none mt-1 group-hover:text-sky-500 dark:group-hover:text-sky-400">
                  {item.label}
                </span>
              </button>
            );
          })}
        </div>

        <p className="text-[9px] text-slate-400/80 dark:text-slate-500 text-center font-mono tracking-widest uppercase mt-6 pt-3 border-t border-slate-100 dark:border-slate-800">
          Valora Secure Sovereign Node
        </p>
      </div>
    </div>
  );
}
