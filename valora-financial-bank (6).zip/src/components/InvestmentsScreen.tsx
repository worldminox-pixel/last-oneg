import React, { useState } from "react";
import { TrendingUp, ArrowUpRight, ShieldCheck, Landmark, Briefcase, Plus, Coins, Zap, CheckCircle, Flame, Building, ArrowDownRight, RefreshCw, ChevronLeft, ChevronRight, KeyRound, Eye, EyeOff, X } from "lucide-react";
import { UserProfile, UserInvestment, InvestmentSettings } from "../types";
import { fmtMoney } from "../utils";
import { INITIAL_PROPERTIES, Property, getPropertyImages } from "./InvestmentProperties";

interface InvestmentsScreenProps {
  user: UserProfile;
  dark: boolean;
  investmentSettings?: InvestmentSettings;
  onUpdateState: (modifier: (s: any) => any) => void;
  onAddTransaction: (tx: any) => void;
  onAddNotification: (notif: any) => void;
  initialTab?: "portfolio" | "bitcoin" | "properties";
  enabledTabTypes?: ("checking" | "investment" | "bitcoin")[];
}

interface AssetOption {
  id: string;
  name: string;
  type: "STOCKS" | "BONDS" | "CRYPTO" | "REAL_ESTATE";
  rate: string;
  description: string;
  minAmount: number;
}

export function InvestmentsScreen({
  user,
  dark,
  investmentSettings,
  onUpdateState,
  onAddTransaction,
  onAddNotification,
  initialTab,
  enabledTabTypes,
}: InvestmentsScreenProps) {
  const [investInputAmount, setInvestInputAmount] = useState<string>("");
  const [selectedAssetId, setSelectedAssetId] = useState<string>("s-p-500");

  // Security PIN states
  const [isPinModalOpen, setIsPinModalOpen] = useState(false);
  const [enteredPin, setEnteredPin] = useState("");
  const [pinError, setPinError] = useState("");
  const [showPinValue, setShowPinValue] = useState(false);
  const [pinActionCallback, setPinActionCallback] = useState<(() => void) | null>(null);
  const [pinModalAmount, setPinModalAmount] = useState<number>(0);

  const allowedTabs = enabledTabTypes || user.enabledAccounts || ["checking", "investment", "bitcoin"];

  const getStartingTab = (): "portfolio" | "bitcoin" | "properties" => {
    if (initialTab) {
      if ((initialTab === "portfolio" || initialTab === "properties") && allowedTabs.includes("investment")) {
        return initialTab;
      }
      if (initialTab === "bitcoin" && allowedTabs.includes("bitcoin")) {
        return initialTab;
      }
    }
    if (allowedTabs.includes("investment")) return "portfolio";
    if (allowedTabs.includes("bitcoin")) return "bitcoin";
    return "portfolio";
  };

  const [fundingTab, setFundingTab] = useState<"portfolio" | "bitcoin" | "properties">(getStartingTab);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);
  const [liquidateSuccessMsg, setLiquidateSuccessMsg] = useState<string | null>(null);
  
  const [properties] = useState<Property[]>(() => {
    try {
      const saved = localStorage.getItem("valora_properties");
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) {
          const validated = parsed.filter((p: any) => p && typeof p === "object" && p.id && p.name && typeof p.price === "number");
          if (validated.length > 0) {
            // Keep custom props created by the user (not in INITIAL_PROPERTIES)
            const customProperties = validated.filter((p: any) => !INITIAL_PROPERTIES.some(ip => ip.id === p.id));
            // For core properties in INITIAL_PROPERTIES, merge them but prioritize codebase updates
            const mergedCoreProperties = INITIAL_PROPERTIES.map(coreProp => {
              const matchedProp = validated.find((p: any) => p.id === coreProp.id);
              if (matchedProp) {
                return {
                  ...matchedProp,
                  name: coreProp.name,
                  type: coreProp.type,
                  category: coreProp.category,
                  location: coreProp.location,
                  imageUrl: coreProp.imageUrl,
                  imageUrls: coreProp.imageUrls,
                  price: coreProp.price,
                  durationMonths: coreProp.durationMonths,
                  expectedMonthlyProfit: coreProp.expectedMonthlyProfit,
                  expectedAnnualProfit: coreProp.expectedAnnualProfit,
                  roiPercentage: coreProp.roiPercentage,
                  description: coreProp.description,
                  features: coreProp.features,
                  riskLevel: coreProp.riskLevel
                };
              }
              return coreProp;
            });
            return [...mergedCoreProperties, ...customProperties];
          }
        }
      }
    } catch (e) {
      console.error("Valora Investments Screen: properties fetch error", e);
    }
    return INITIAL_PROPERTIES;
  });
  const [selectedPropertyId, setSelectedPropertyId] = useState<string>(() => {
    return INITIAL_PROPERTIES[0]?.id || "";
  });
  const [propertyPictureIndexes, setPropertyPictureIndexes] = useState<Record<string, number>>({});

  const activeDailyRate = investmentSettings?.portfolioDailyPercentage ?? 1.5;
  const activeDuration = investmentSettings?.portfolioDurationDays ?? 30;
  const activeBtcDailyRate = investmentSettings?.bitcoinDailyPercentage ?? 2.0;
  const activeBtcDuration = investmentSettings?.bitcoinDurationDays ?? 30;
  const activeBoostRate = investmentSettings?.instantFundingBonusPercentage ?? 5.5;

  // High-fidelity available investment assets with dynamic administrative rates
  const ASSETS: AssetOption[] = [
    {
      id: "s-p-500",
      name: "S&P 500® Blue-Chip Index",
      type: "STOCKS",
      rate: `${activeDailyRate.toFixed(2)}% Daily (${(activeDailyRate * activeDuration).toFixed(1)}% Yield)`,
      description: `Direct exposure to United States' top five hundred blue-chip equities compounded over ${activeDuration} days.`,
      minAmount: 500
    },
    {
      id: "us-bonds",
      name: "US Fed Treasury 10Y Bond",
      type: "BONDS",
      rate: `${(activeDailyRate * 0.8).toFixed(2)}% Daily (${((activeDailyRate * 0.8) * activeDuration).toFixed(1)}% Guarantee)`,
      description: `Sovereign debt interest reserves backed by United States Government credit. Compounded for ${activeDuration} days.`,
      minAmount: 1000
    },
    {
      id: "manhattan-re",
      name: "Manhattan Commercial Real Estate ETF",
      type: "REAL_ESTATE",
      rate: `${(activeDailyRate * 0.9).toFixed(2)}% Daily (${((activeDailyRate * 0.9) * activeDuration).toFixed(1)}% Rental APY)`,
      description: `Yielding premium logistics centers, luxury residences, and retail complexes in Manhattan New York. Returns paid out in ${activeDuration} days.`,
      minAmount: 2500
    },
    {
      id: "us-ai",
      name: "Valora Managed Tech Index",
      type: "STOCKS",
      rate: `${(activeDailyRate * 1.25).toFixed(2)}% Daily (${((activeDailyRate * 1.25) * activeDuration).toFixed(1)}% Active Yield)`,
      description: `Risk-adjusted active capital leveraging machine-learning optimization inside NASDAQ-100 high-growth US tech equities. Returns mature in ${activeDuration} days.`,
      minAmount: 100
    }
  ];

  const hasInvestmentAccount = user.investmentBalance !== undefined;
  const currentInvestments = user.investmentsList || [];
  const activeInvestments = currentInvestments.filter(inv => inv.status === "ACTIVE");

  const handleApplyAccount = () => {
    onUpdateState((s: any) => {
      const users = s.users.map((u: any) => {
        if (u.id === user.id) {
          return {
            ...u,
            investmentBalance: 0,
            investmentsList: []
          };
        }
        return u;
      });
      return { ...s, users };
    });

    const notif = {
      id: "notif-inv-" + Math.floor(Math.random() * 10000),
      userId: user.id,
      title: "Wealth Portfolio Activated",
      body: "Institutional Investment and Wealth subaccounts successfully provisioned. Real-time US clearances active.",
      read: false,
      date: new Date().toISOString()
    };
    onAddNotification(notif);
  };

  const handleBuyAsset = (e: React.FormEvent) => {
    e.preventDefault();
    if (user.checkingFrozen) {
      alert("Transaction Declined: Your premium liquid checking account is frozen by governance compliance. Asset procurement is temporarily suspended.");
      return;
    }
    if ((fundingTab === "portfolio" || fundingTab === "properties") && user.investmentFrozen) {
      alert("Transaction Declined: Your wealth investment portfolio account is frozen by governance compliance.");
      return;
    }
    if (fundingTab === "bitcoin" && user.bitcoinFrozen) {
      alert("Transaction Declined: Your sovereign bitcoin cold storage vault is frozen by governance compliance.");
      return;
    }
    const amt = parseFloat(investInputAmount);
    if (isNaN(amt) || amt <= 0) {
      alert("Please specify a valid dollar amount");
      return;
    }

    if (amt > user.balance) {
      alert("Insufficient funds in your checked liquid wallet.");
      return;
    }

    const runPurchase = () => {

    if (fundingTab === "portfolio") {
      const selectedAsset = ASSETS.find(a => a.id === selectedAssetId);
      if (!selectedAsset) return;

      if (amt < selectedAsset.minAmount) {
        alert(`The clearing threshold for ${selectedAsset.name} is ${fmtMoney(selectedAsset.minAmount)}.`);
        return;
      }

      // Calculate investment values including boot bonuses
      const bonusPct = activeBoostRate;
      const bonusAmt = amt * (bonusPct / 100);
      const startingVal = amt + bonusAmt;

      // Process Purchase
      onUpdateState((s: any) => {
        const users = s.users.map((u: any) => {
          if (u.id === user.id) {
            const prevBalance = u.balance || 0;
            const prevInvBalance = u.investmentBalance || 0;
            const newList = u.investmentsList || [];

            const newInvestItem: UserInvestment = {
              id: "INV-ITEM-" + Math.random().toString(36).slice(2, 8).toUpperCase(),
              assetId: selectedAsset.id,
              assetName: selectedAsset.name,
              assetType: selectedAsset.type,
              investedAmount: amt,
              currentValue: startingVal, // Boosted starting value!
              yieldRate: selectedAsset.rate,
              date: new Date().toISOString(),
              status: "ACTIVE"
            };

            return {
              ...u,
              balance: prevBalance - amt,
              investmentBalance: prevInvBalance + startingVal,
              investmentsList: [newInvestItem, ...newList]
            };
          }
          return u;
        });
        return { ...s };
      });

      // Add transaction ledger entry
      const tx = {
        id: "VFB-INV-" + Math.floor(100000 + Math.random() * 900000),
        fromUserId: user.id,
        toUserId: "EXTERNAL",
        fromName: user.name,
        toName: `Portfolio: ${selectedAsset.name}`,
        fromAccountNumber: user.accountNumber,
        toAccountNumber: `PORTFOLIO-LEDGER-${selectedAsset.id.toUpperCase()}`,
        amount: amt,
        note: `Capital Investment: Buy ${selectedAsset.name} (Includes +${bonusPct}% Instantly Cleared Market Incentive of ${fmtMoney(bonusAmt)})`,
        date: new Date().toISOString(),
        status: "Successful",
        transactionType: "Asset Purchase Clearance",
        recipientBank: "Valora Private Asset Management",
        fromBank: "Valora Private Bank",
        timeZone: "CET (UTC+1)",
        processingFee: 0,
        serviceCharge: 0,
        totalAmount: amt,
        ipAddress: "178.238.165.73"
      };
      onAddTransaction(tx);

      // Notification
      const notif = {
        id: "notif-inv-buy-" + Math.floor(Math.random() * 10000),
        userId: user.id,
        title: "Asset Purchase Cleared",
        body: `Successfully invested ${fmtMoney(amt)} in ${selectedAsset.name}. Administrative balance match +${bonusPct}% booster added.`,
        read: false,
        date: new Date().toISOString()
      };
      onAddNotification(notif);

      setSuccessMsg(`Asset purchased successfully! ${fmtMoney(amt)} was allocated with +${bonusPct}% market booster (${fmtMoney(bonusAmt)}) added instantly.`);
      setInvestInputAmount("");
      setTimeout(() => setSuccessMsg(null), 5000);

    } else if (fundingTab === "properties") {
      const selectedProperty = properties.find(p => p.id === selectedPropertyId);
      if (!selectedProperty) return;

      if (amt < 1000) {
        alert("The minimum investment amount in trophy real estate is $1,000.");
        return;
      }

      // Calculate investment values including boot bonuses
      const bonusPct = activeBoostRate;
      const bonusAmt = amt * (bonusPct / 100);
      const startingVal = amt + bonusAmt;

      // Process Purchase
      onUpdateState((s: any) => {
        const users = s.users.map((u: any) => {
          if (u.id === user.id) {
            const prevBalance = u.balance || 0;
            const prevInvBalance = u.investmentBalance || 0;
            const newList = u.investmentsList || [];

            const newInvestItem: UserInvestment = {
              id: "INV-REAL-" + Math.random().toString(36).slice(2, 8).toUpperCase(),
              assetId: selectedProperty.id,
              assetName: selectedProperty.name,
              assetType: "REAL_ESTATE",
              investedAmount: amt,
              currentValue: startingVal, // Boosted starting value!
              yieldRate: `${selectedProperty.roiPercentage}% Annual Yield`,
              date: new Date().toISOString(),
              status: "ACTIVE"
            };

            return {
              ...u,
              balance: prevBalance - amt,
              investmentBalance: prevInvBalance + startingVal,
              investmentsList: [newInvestItem, ...newList]
            };
          }
          return u;
        });
        return { ...s };
      });

      // Add transaction ledger entry
      const tx = {
        id: "VFB-REAL-" + Math.floor(100000 + Math.random() * 900000),
        fromUserId: user.id,
        toUserId: "EXTERNAL",
        fromName: user.name,
        toName: `Fractional: ${selectedProperty.name}`,
        fromAccountNumber: user.accountNumber,
        toAccountNumber: `CUSTODY-REAL-${selectedProperty.id.toUpperCase()}`,
        amount: amt,
        note: `Fractional Estate Acquisition: Rent-To-Yield index in ${selectedProperty.name} (${selectedProperty.location}). Includes +${bonusPct}% custody match booster of ${fmtMoney(bonusAmt)}.`,
        date: new Date().toISOString(),
        status: "Successful",
        transactionType: "Sovereign Asset Buy-In",
        recipientBank: "Valora Premium Real Estate Custody",
        fromBank: "Valora Private Bank",
        timeZone: "CET (UTC+1)",
        processingFee: 0,
        serviceCharge: 0,
        totalAmount: amt,
        ipAddress: "178.238.165.73"
      };
      onAddTransaction(tx);

      // Notification
      const notif = {
        id: "notif-prop-buy-" + Math.floor(Math.random() * 10000),
        userId: user.id,
        title: "Estate Investment Cleared",
        body: `Approved fractional buy-in of ${fmtMoney(amt)} in ${selectedProperty.name} at ${selectedProperty.location}. Welcome to premium high-yield real estate custody.`,
        read: false,
        date: new Date().toISOString()
      };
      onAddNotification(notif);

      setSuccessMsg(`Fractional investment complete! ${fmtMoney(amt)} was allocated to ${selectedProperty.name} with +${bonusPct}% matched booster added instantly.`);
      setInvestInputAmount("");
      setTimeout(() => setSuccessMsg(null), 5000);

    } else {
      // BTC Vault Funding
      const bonusPct = activeBoostRate;
      const btcPrice = 68500; // Reference BTC spot price
      const bonusAmt = amt * (bonusPct / 100);
      const totalUSDValue = amt + bonusAmt;
      const btcPurchased = totalUSDValue / btcPrice;

      // Process Bitcoin Purchase
      onUpdateState((s: any) => {
        const users = s.users.map((u: any) => {
          if (u.id === user.id) {
            const prevBalance = u.balance || 0;
            const prevBtc = u.bitcoinBalance || 0;

            return {
              ...u,
              balance: prevBalance - amt,
              bitcoinBalance: Math.round((prevBtc + btcPurchased) * 100000) / 100000
            };
          }
          return u;
        });
        return { ...s };
      });

      // Add transaction ledger entry
      const tx = {
        id: "VFB-BTC-" + Math.floor(100000 + Math.random() * 900000),
        fromUserId: user.id,
        toUserId: "EXTERNAL",
        fromName: user.name,
        toName: "Bitcoin Secured Sovereign Vault",
        fromAccountNumber: user.accountNumber,
        toAccountNumber: "BITCOIN-SECURE-VAULT-MAIN",
        amount: amt,
        note: `Secure Bitcoin Credit (Acquired ${btcPurchased.toFixed(5)} BTC at $68,500/BTC rate, includes +${bonusPct}% administrative booster of ${fmtMoney(bonusAmt)})`,
        date: new Date().toISOString(),
        status: "Successful",
        transactionType: "Sovereign Asset Buy-In",
        recipientBank: "Valora Brokerage & Wealth Clearinghouse",
        fromBank: "Valora Private Bank",
        timeZone: "CET (UTC+1)",
        processingFee: 0,
        serviceCharge: 0,
        totalAmount: amt,
        ipAddress: "178.238.165.73"
      };
      onAddTransaction(tx);

      // Notification
      const notif = {
        id: "notif-btc-buy-" + Math.floor(Math.random() * 10000),
        userId: user.id,
        title: "Bitcoin Vault Funded",
        body: `Approved purchase of ${btcPurchased.toFixed(5)} BTC credited instantly to secure vault. APY compounding activated.`,
        read: false,
        date: new Date().toISOString()
      };
      onAddNotification(notif);

      setSuccessMsg(`Bitcoin subaccount funded successfully! ${btcPurchased.toFixed(5)} BTC credited ($${amt.toLocaleString()} principal with +${bonusPct}% booster added).`);
      setInvestInputAmount("");
      setTimeout(() => setSuccessMsg(null), 5000);
    }

    };

    setEnteredPin("");
    setPinError("");
    setPinModalAmount(amt);
    setPinActionCallback(() => runPurchase);
    setIsPinModalOpen(true);
  };

  const handleLiquidateAsset = (item: UserInvestment) => {
    if (user.checkingFrozen) {
      alert("Withdrawal Denied: Liquid checking balance route is frozen. Liquidation cannot settle.");
      return;
    }
    if (user.investmentFrozen) {
      alert("Withdrawal Denied: Wealth investment portfolio is frozen.");
      return;
    }
    if (item.status === "LIQUIDATED") return;

    const value = item.currentValue;

    const runLiquidation = () => {

    // Process Liquidation
    onUpdateState((s: any) => {
      const users = s.users.map((u: any) => {
        if (u.id === user.id) {
          const prevBalance = u.balance || 0;
          const prevInvBalance = u.investmentBalance || 0;
          const list = u.investmentsList || [];

          const updatedList = list.map((inv: UserInvestment) => {
            if (inv.id === item.id) {
              return { ...inv, status: "LIQUIDATED" as const };
            }
            return inv;
          });

          return {
            ...u,
            balance: prevBalance + value,
            investmentBalance: Math.max(0, prevInvBalance - item.investedAmount),
            investmentsList: updatedList
          };
        }
        return u;
      });
      return { ...s };
    });

    // Add transaction ledger entry
    const tx = {
      id: "VFB-LIQ-" + Math.floor(100000 + Math.random() * 900000),
      fromUserId: "EXTERNAL",
      toUserId: user.id,
      fromName: `Liquidated: ${item.assetName}`,
      toName: user.name,
      fromAccountNumber: `PORTFOLIO-LEDGER-${item.assetId.toUpperCase()}`,
      toAccountNumber: user.accountNumber,
      amount: value,
      note: `Capital Liquidation Clearance: Sell ${item.assetName}`,
      date: new Date().toISOString(),
      status: "Successful",
      transactionType: "Asset Liquidation clearance",
      recipientBank: "Valora Private Bank",
      fromBank: "Valora Private Asset Management",
      timeZone: "CET (UTC+1)",
      processingFee: 0,
      serviceCharge: 0,
      totalAmount: value,
      ipAddress: "178.238.165.73"
    };
    onAddTransaction(tx);

    // Notification
    const notif = {
      id: "notif-inv-liq-" + Math.floor(Math.random() * 10000),
      userId: user.id,
      title: "Asset Liquidation Cleared",
      body: `Liquidated ${fmtMoney(value)} from ${item.assetName}. Capital cleared directly back to checked checking route.`,
      read: false,
      date: new Date().toISOString()
    };
    onAddNotification(notif);

    setLiquidateSuccessMsg(`Successfully cleared ${fmtMoney(value)} holdings to Checking.`);
    setTimeout(() => setLiquidateSuccessMsg(null), 5000);
    };

    setEnteredPin("");
    setPinError("");
    setPinModalAmount(value);
    setPinActionCallback(() => runLiquidation);
    setIsPinModalOpen(true);
  };

  return (
    <div className="px-5 pb-24 animate-[fadeIn_0.2s_ease-out] select-none">
      {/* Dynamic 3-Axis Balance Overview Header */}
      <div className={`p-5 rounded-3xl mb-6 border ${
        dark ? "bg-slate-900/60 border-slate-800" : "bg-sky-50/50 border-sky-100/40 shadow-sm"
      }`}>
        <div className="flex items-center gap-2 mb-3">
          <Briefcase size={16} className="text-teal-500" />
          <h4 className="text-[10px] font-mono font-black uppercase tracking-widest text-slate-400">
            Sovereign Asset Allocation
          </h4>
        </div>
        <div className="grid grid-cols-3 gap-2">
          <div className="p-2 bg-slate-100/30 rounded-xl">
            <span className="text-[8px] font-bold text-slate-400 block uppercase">Liquid Checked</span>
            <span className="text-xs font-mono font-black text-sky-500 block break-words mt-0.5">{fmtMoney(user.balance)}</span>
          </div>
          <div className="p-2 bg-slate-100/30 rounded-xl">
            <span className="text-[8px] font-bold text-slate-400 block uppercase">Bitcoin Vault</span>
            <span className="text-xs font-mono font-black text-amber-500 block break-words mt-0.5">{(user.bitcoinBalance ?? 0).toFixed(4)} BTC</span>
          </div>
          <div className="p-2 bg-slate-100/30 rounded-xl">
            <span className="text-[8px] font-bold text-slate-400 block uppercase">Portfolios</span>
            <span className="text-xs font-mono font-black text-teal-500 block break-words mt-0.5">{fmtMoney(user.investmentBalance ?? 0)}</span>
          </div>
        </div>
      </div>

      {!hasInvestmentAccount ? (
        /* APPLICATION WORKSPACE ENTRY GATEWAY */
        <div className={`p-6 rounded-3xl text-center border ${
          dark ? "bg-slate-900/40 border-slate-800" : "bg-white border-slate-200/90 shadow-lg"
        }`}>
          <div className="w-12 h-12 rounded-2xl bg-teal-50 text-teal-600 flex items-center justify-center mx-auto mb-4 border border-teal-100">
            <TrendingUp size={24} />
          </div>
          <h3 className="text-sm font-black uppercase tracking-wider text-slate-900">
            Open Wealth Portfolio Account
          </h3>
          <p className="text-[11px] leading-relaxed text-slate-500 mt-2 max-w-sm mx-auto">
            Leverage sovereign asset allocations. Activate your private wealth subaccount to trade blue-chip equities, treasury bond guarantees, and prime commercial complexes.
          </p>

          <div className="rounded-xl bg-slate-50 border border-slate-100 p-3 mt-4 text-left space-y-2 text-[10px] text-slate-600 font-medium">
            <div className="flex items-center gap-2">
              <ShieldCheck size={12} className="text-emerald-500 shrink-0" />
              <span>Full compliance with SEC & FDIC asset custody directives.</span>
            </div>
            <div className="flex items-center gap-2">
              <Coins size={12} className="text-sky-500 shrink-0" />
              <span>Purchase assets directly from your checking holdings.</span>
            </div>
            <div className="flex items-center gap-2">
              <Zap size={12} className="text-amber-500 shrink-0" />
              <span>Instant 24/7 liquidation clearance back to liquid cash.</span>
            </div>
          </div>

          <button
            onClick={handleApplyAccount}
            className="w-full mt-5 py-3.5 bg-slate-900 hover:bg-slate-800 text-white font-black text-xs uppercase tracking-widest rounded-2xl transition-all cursor-pointer shadow hover:shadow-md"
          >
            Apply & Activate Account
          </button>
        </div>
      ) : (
        /* INSTANT HIGH-YIELD TRADING OFFICE */
        <div className="space-y-6">
          {/* Active Allocations Portfolio */}
          <div>
            <div className="flex justify-between items-center mb-3">
              <h3 className="text-xs font-black uppercase tracking-wider text-slate-400">
                Active Wealth Assets
              </h3>
              <span className="text-[10px] font-mono bg-teal-500/10 text-teal-600 font-bold px-2.5 py-0.5 rounded-full">
                {activeInvestments.length} Active Positions
              </span>
            </div>

            {liquidateSuccessMsg && (
              <div className="p-3 mb-3 bg-emerald-50 text-emerald-700 text-[11px] font-semibold rounded-xl border border-emerald-100 flex items-center gap-2 animate-[fadeIn_0.2s]">
                <CheckCircle size={12} />
                <span>{liquidateSuccessMsg}</span>
              </div>
            )}

            {activeInvestments.length === 0 ? (
              <div className="p-6 text-center rounded-2xl border border-dashed border-slate-200 bg-slate-50/50">
                <p className="text-[11px] text-slate-400 leading-relaxed">
                  Your investment subaccount is empty.<br />Allocate funds below to build institutional wealth.
                </p>
              </div>
            ) : (
              <div className="space-y-2.5">
                {activeInvestments.map((inv) => {
                  let badgeCol = "bg-sky-50 text-sky-600 border-sky-100";
                  if (inv.assetType === "BONDS") badgeCol = "bg-teal-50 text-teal-600 border-teal-100";
                  if (inv.assetType === "REAL_ESTATE") badgeCol = "bg-amber-50 text-amber-600 border-amber-100";
                  
                  return (
                    <div 
                      key={inv.id}
                      className="p-4 bg-white border border-slate-100/90 rounded-2xl shadow-sm flex justify-between items-center transition-all hover:border-slate-200/50"
                    >
                      <div>
                        <div className="flex items-center gap-1.5 flex-wrap">
                          <span className={`text-[8px] font-extrabold uppercase font-mono px-2 py-0.5 rounded border ${badgeCol}`}>
                            {inv.assetType}
                          </span>
                          <span className="text-[10px] font-mono text-emerald-500 font-black">{inv.yieldRate}</span>
                        </div>
                        <h4 className="text-xs font-black text-slate-900 uppercase mt-1">
                          {inv.assetName}
                        </h4>
                        <p className="text-[9px] text-slate-400 font-mono mt-0.5">
                          Purchase Price: {fmtMoney(inv.investedAmount)} &bull; Date: {new Date(inv.date).toLocaleDateString("en-US", { timeZone: "America/New_York" })}
                        </p>
                      </div>

                      <div className="text-right flex flex-col items-end">
                        <span className="text-xs font-mono font-black text-slate-900">{fmtMoney(inv.currentValue)}</span>
                        <button
                          onClick={() => handleLiquidateAsset(inv)}
                          className="mt-1 pb-0.5 border-b border-rose-500 hover:text-rose-600 text-rose-500 text-[10px] font-extrabold uppercase tracking-wide cursor-pointer leading-tight"
                        >
                          Liquidate
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>

          {/* Secure Allocation Procurement Panel */}
          <div className="p-5 rounded-3xl bg-slate-900 text-white relative overflow-hidden shadow-xl">
            {/* Visual background element */}
            <div className="absolute top-0 right-0 w-32 h-32 bg-teal-500/10 rounded-full blur-2xl pointer-events-none" />

            <div className="relative flex items-center justify-between border-b border-white/10 pb-3 mb-4">
              <div>
                <span className="text-[8px] font-mono text-teal-400 font-black uppercase tracking-wider">Trading Office</span>
                <h4 className="text-xs font-black uppercase tracking-wider">Allocate Capital Reserve</h4>
              </div>
              <ShieldCheck size={16} className="text-teal-400" />
            </div>

            {/* Dynamic Funding Toggle Tab */}
            <div className="flex bg-white/5 p-1 rounded-2xl mb-4 gap-1">
              <button
                type="button"
                onClick={() => {
                  setFundingTab("portfolio");
                  setSuccessMsg(null);
                }}
                className={`flex-1 py-2 text-[9px] font-black uppercase tracking-wider rounded-lg transition-all ${
                  fundingTab === "portfolio"
                    ? "bg-teal-500 text-slate-950 shadow-sm"
                    : "text-slate-300 hover:text-white"
                }`}
              >
                Portfolios
              </button>
              <button
                type="button"
                onClick={() => {
                  setFundingTab("bitcoin");
                  setSuccessMsg(null);
                }}
                className={`flex-1 py-2 text-[9px] font-black uppercase tracking-wider rounded-lg transition-all ${
                  fundingTab === "bitcoin"
                    ? "bg-amber-500 text-slate-950 shadow-sm"
                    : "text-slate-300 hover:text-white"
                }`}
              >
                Bitcoin
              </button>
              <button
                type="button"
                onClick={() => {
                  setFundingTab("properties");
                  setSuccessMsg(null);
                }}
                className={`flex-1 py-2 text-[9px] font-black uppercase tracking-wider rounded-lg transition-all ${
                  fundingTab === "properties"
                    ? "bg-sky-500 text-slate-950 shadow-sm"
                    : "text-slate-300 hover:text-white"
                }`}
              >
                Real Estate
              </button>
            </div>

            {successMsg && (
              <div className="p-3 mb-4 bg-teal-500/20 text-teal-300 text-[11px] font-semibold rounded-xl border border-teal-500/30 flex items-center gap-2 animate-[fadeIn_0.2s]">
                <CheckCircle size={12} className="text-teal-400" />
                <span>{successMsg}</span>
              </div>
            )}

            <form onSubmit={handleBuyAsset} className="space-y-4">
              {fundingTab === "portfolio" ? (
                <div>
                  <label className="text-[9px] text-slate-400 font-black uppercase tracking-wider block mb-1">
                    1. Select Portfolio Asset
                  </label>
                  <p className="text-[9.5px] text-teal-400 font-bold mb-2 flex items-center gap-1">
                    <Zap size={10} /> Active Multi-Asset Incentive: +{activeBoostRate.toFixed(1)}% extra credited funds instantly!
                  </p>
                  <div className="grid grid-cols-1 gap-2">
                    {ASSETS.map((ast) => {
                      const selected = selectedAssetId === ast.id;
                      return (
                        <div
                          key={ast.id}
                          onClick={() => setSelectedAssetId(ast.id)}
                          className={`p-3 rounded-xl border cursor-pointer transition-all ${
                            selected 
                              ? "bg-white/10 border-teal-500" 
                              : "bg-white/5 border-white/5 hover:bg-white/10"
                          }`}
                        >
                          <div className="flex justify-between items-start">
                            <div>
                              <span className="text-[9px] font-bold text-teal-400 uppercase font-mono">{ast.rate}</span>
                              <h5 className="text-[11px] font-extrabold uppercase text-white mt-0.5">{ast.name}</h5>
                            </div>
                            <input 
                              type="radio" 
                              checked={selected} 
                              readOnly
                              className="cursor-pointer accent-teal-500 mt-0.5"
                            />
                          </div>
                          <p className="text-[9px] text-slate-400 leading-normal mt-1 pr-4">{ast.description}</p>
                          <span className="text-[8px] font-mono text-slate-500 block mt-1.5 uppercase font-medium">
                            Min threshold: {fmtMoney(ast.minAmount)} clearance
                          </span>
                        </div>
                      );
                    })}
                  </div>
                </div>
              ) : fundingTab === "properties" ? (
                <div>
                  <label className="text-[9px] text-slate-400 font-black uppercase tracking-wider block mb-1">
                    1. Select Direct Property Asset
                  </label>
                  <p className="text-[9.5px] text-sky-450 text-sky-400 font-bold mb-2 flex items-center gap-1">
                    <Zap size={10} /> Sovereign Property Incentive: +{activeBoostRate.toFixed(1)}% instant leverage bonus!
                  </p>
                  
                  <div className="grid grid-cols-1 gap-2.5 max-h-[320px] overflow-y-auto pr-1">
                    {properties.filter(Boolean).map((prop) => {
                      if (!prop || !prop.id) return null;
                      const selected = selectedPropertyId === prop.id;
                      const images = getPropertyImages(prop);
                      const activeImgIdx = propertyPictureIndexes[prop.id] || 0;

                      const handlePrevImg = (e: React.MouseEvent) => {
                        e.stopPropagation();
                        setPropertyPictureIndexes(prev => ({
                          ...prev,
                          [prop.id]: activeImgIdx === 0 ? images.length - 1 : activeImgIdx - 1
                        }));
                      };

                      const handleNextImg = (e: React.MouseEvent) => {
                        e.stopPropagation();
                        setPropertyPictureIndexes(prev => ({
                          ...prev,
                          [prop.id]: activeImgIdx === images.length - 1 ? 0 : activeImgIdx + 1
                        }));
                      };

                      return (
                        <div
                          key={prop.id}
                          onClick={() => setSelectedPropertyId(prop.id)}
                          className={`p-3 rounded-xl border cursor-pointer transition-all flex gap-3 ${
                            selected 
                              ? "bg-white/10 border-sky-500" 
                              : "bg-white/5 border-white/5 hover:bg-white/10"
                          }`}
                        >
                          {/* Mini Image Carousel */}
                          <div className="relative w-20 h-20 rounded-lg overflow-hidden shrink-0 bg-slate-800 border border-white/10">
                            <img 
                              src={images[activeImgIdx]} 
                              className="w-full h-full object-cover select-none"
                              referrerPolicy="no-referrer"
                              alt=""
                            />
                            {images.length > 1 && (
                              <>
                                <button
                                  type="button"
                                  onClick={handlePrevImg}
                                  className="absolute left-0.5 top-1/2 -translate-y-1/2 bg-black/60 hover:bg-black/80 rounded-full p-1 text-white/90 cursor-pointer z-10"
                                >
                                  <ChevronLeft size={8} />
                                </button>
                                <button
                                  type="button"
                                  onClick={handleNextImg}
                                  className="absolute right-0.5 top-1/2 -translate-y-1/2 bg-black/60 hover:bg-black/80 rounded-full p-1 text-white/90 cursor-pointer z-10"
                                >
                                  <ChevronRight size={8} />
                                </button>
                                <span className="absolute bottom-0.5 right-1 text-[7px] bg-black/70 text-white px-1 rounded font-mono">
                                  {activeImgIdx + 1}/{images.length}
                                </span>
                              </>
                            )}
                          </div>

                          {/* Info Column */}
                          <div className="flex-1 min-w-0 flex flex-col justify-between">
                            <div>
                              <div className="flex justify-between items-start gap-1">
                                <span className="text-[7.5px] font-bold text-sky-400 font-mono tracking-wide uppercase truncate block shrink-0">
                                  {prop.roiPercentage}% APY Range
                                </span>
                                <span className="text-[7.5px] font-mono bg-sky-500/10 text-sky-450 text-sky-450 border border-sky-500/20 px-1.5 py-0.2 rounded-full font-bold uppercase scale-95 origin-right">
                                  {prop.status}
                                </span>
                              </div>
                              <h5 className="text-[10px] font-black text-white uppercase truncate mt-0.5 block leading-tight">
                                {prop.name}
                              </h5>
                              <p className="text-[8px] text-slate-400 truncate flex items-center gap-0.5 mt-0.5 leading-snug">
                                {prop.location}
                              </p>
                            </div>
                            <div className="flex justify-between items-end mt-1">
                              <span className="text-[8px] font-mono text-slate-400">
                                Capital: <strong className="text-white font-mono">{fmtMoney(prop.price)}</strong>
                              </span>
                              <input 
                                type="radio" 
                                checked={selected} 
                                readOnly
                                className="cursor-pointer accent-sky-500"
                              />
                            </div>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>
              ) : (
                <div className="p-4 bg-white/5 rounded-2xl border border-amber-500/15 space-y-3">
                  <div className="flex justify-between items-center">
                    <span className="text-[10px] font-black uppercase tracking-wider text-amber-500 flex items-center gap-1 font-mono">
                      <Coins size={12} /> Bitcoin Secured Vault Route
                    </span>
                    <span className="text-[9px] font-mono bg-amber-500/10 text-amber-500 px-2.5 py-0.5 rounded-full">
                      Spot: $68,500/BTC
                    </span>
                  </div>
                  <p className="text-[10px] text-slate-300 leading-relaxed">
                    Sovereign appreciation is fully configured. Funding includes a <strong className="text-amber-500">+{activeBoostRate.toFixed(1)}% instant leverage booster</strong> credited on checkout.
                  </p>
                  <div className="grid grid-cols-2 gap-2 text-[9px] font-mono text-slate-400">
                    <div className="bg-white/5 p-2 rounded-lg">
                      <span>Daily Growth APY:</span>
                      <span className="block text-amber-500 font-extrabold text-xs mt-0.5">+{activeBtcDailyRate.toFixed(2)}% Daily</span>
                    </div>
                    <div className="bg-white/5 p-2 rounded-lg">
                      <span>Market Duration Days:</span>
                      <span className="block text-white font-extrabold text-xs mt-0.5">{activeBtcDuration} Days</span>
                    </div>
                  </div>
                </div>
              )}
              
              <div>
                <label className="text-[9px] text-slate-400 font-black uppercase tracking-wider block mb-1">
                  {fundingTab === "portfolio" 
                    ? "2. Clear Investment Amount (Debit liquid checked route)" 
                    : fundingTab === "properties" 
                      ? "2. Clear Allocation Amount (Debit liquid checked route)" 
                      : "Clear Procurement Amount (Debit liquid checked route)"}
                </label>
                <div className="relative">
                  <span className="absolute left-4 top-1/2 -translate-y-1/2 text-sm font-bold text-slate-400 font-mono">$</span>                  <input
                    type="number"
                    placeholder="0.00"
                    value={investInputAmount}
                    onChange={(e) => setInvestInputAmount(e.target.value)}
                    className={`w-full p-3.5 pl-8 rounded-xl bg-white/5 text-white outline-none border border-white/10 font-extrabold text-xs font-mono transition-all ${
                      fundingTab === "properties"
                        ? "focus:border-sky-500"
                        : fundingTab === "bitcoin"
                          ? "focus:border-amber-500"
                          : "focus:border-teal-500"
                    }`}
                  />
                </div>
                
                {investInputAmount && !isNaN(parseFloat(investInputAmount)) && parseFloat(investInputAmount) > 0 && (
                  <div className={`mt-2.5 p-2.5 rounded-lg border text-[10px] font-mono space-y-1 ${
                    fundingTab === "properties"
                      ? "bg-sky-500/10 border-sky-500/20 text-sky-400"
                      : fundingTab === "bitcoin"
                        ? "bg-amber-500/10 border-amber-500/20 text-amber-400"
                        : "bg-teal-500/10 border-teal-500/20 text-emerald-400"
                  }`}>
                    <div className="flex justify-between">
                      <span>Principal Amount:</span>
                      <span>{fmtMoney(parseFloat(investInputAmount))}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>+{activeBoostRate.toFixed(1)}% Instant Booster:</span>
                      <span>+{fmtMoney((parseFloat(investInputAmount) * activeBoostRate) / 100)}</span>
                    </div>
                    <div className="flex justify-between border-t border-white/10 pt-1 font-bold text-white">
                      <span>Total Account Growth:</span>
                      <span>{fmtMoney(parseFloat(investInputAmount) * (1 + activeBoostRate / 100))}</span>
                    </div>
                  </div>
                )}
 
                <div className="flex justify-between items-center mt-1.5 text-[9.5px] text-slate-400 font-mono">
                  <span>Available Checked Pool:</span>
                  <span className={`font-bold ${
                    fundingTab === "properties"
                      ? "text-sky-450"
                      : fundingTab === "bitcoin"
                        ? "text-amber-500"
                        : "text-teal-400"
                  }`}>{fmtMoney(user.balance)} USD</span>
                </div>
              </div>
 
              <button
                type="submit"
                className={`w-full py-3 ${
                  fundingTab === "portfolio" 
                    ? "bg-teal-500 hover:bg-teal-600 text-slate-950 shadow-teal-500/5 shadow-md" 
                    : fundingTab === "properties"
                      ? "bg-sky-500 hover:bg-sky-600 text-slate-950 shadow-sky-500/5 shadow-md"
                      : "bg-amber-500 hover:bg-amber-600 text-slate-950 shadow-amber-500/5 shadow-md"
                } text-xs tracking-widest font-black uppercase rounded-xl transition-all cursor-pointer flex items-center justify-center gap-1.5`}
              >
                Clear Capital Allocation <ArrowUpRight size={13} className="stroke-[3]" />
              </button>
            </form>
          </div>
        </div>
      )}

      {/* SECURE TRANSACTION PIN CHALLENGE OVERLAY MODAL */}
      {isPinModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-md animate-[fadeIn_0.2s_ease-out]">
          <div className={`w-full max-w-sm p-6 rounded-3xl border shadow-2xl relative ${
            dark ? "bg-slate-900 border-slate-800 text-slate-100" : "bg-white border-slate-200 text-slate-900"
          }`}>
            <button
              onClick={() => {
                setIsPinModalOpen(false);
                setPinActionCallback(null);
              }}
              className="absolute top-4 right-4 p-1.5 rounded-full hover:bg-slate-200 dark:hover:bg-slate-800 transition-colors"
            >
              <X size={18} />
            </button>

            <div className="flex flex-col items-center text-center space-y-4">
              <div className="p-3.5 bg-sky-500/10 text-sky-500 rounded-full ring-4 ring-sky-500/5">
                <KeyRound size={28} className="stroke-[2.5]" />
              </div>

              <div>
                <h3 className="text-lg font-black uppercase tracking-tight text-sky-500">
                  Security PIN Required
                </h3>
                <p className={`text-xs mt-1 ${dark ? "text-slate-400" : "text-slate-500"}`}>
                  Enter your 4-digit security PIN to authorize the investment transaction of <span className="font-bold text-sky-400">{fmtMoney(pinModalAmount)}</span>.
                </p>
              </div>

              <div className="w-full space-y-3">
                <div className="relative">
                  <input
                    type={showPinValue ? "text" : "password"}
                    maxLength={4}
                    placeholder="••••"
                    value={enteredPin}
                    onChange={(e) => {
                      const val = e.target.value.replace(/\D/g, "");
                      setEnteredPin(val);
                      setPinError("");
                    }}
                    className={`w-full p-3.5 rounded-2xl text-center text-lg font-bold tracking-[0.5em] font-mono outline-none border ${
                      pinError 
                        ? "border-rose-500/50 focus:border-rose-500 bg-rose-500/5 text-rose-500" 
                        : dark 
                          ? "bg-slate-950 border-slate-800 text-white focus:border-sky-500" 
                          : "bg-slate-50 border-slate-200 text-slate-900 focus:border-sky-500"
                    }`}
                  />
                  <button
                    type="button"
                    onClick={() => setShowPinValue(!showPinValue)}
                    className="absolute right-4 top-1/2 -translate-y-1/2 text-slate-500 hover:text-slate-300 p-1"
                    title={showPinValue ? "Hide PIN" : "Show PIN"}
                  >
                    {showPinValue ? <EyeOff size={16} /> : <Eye size={16} />}
                  </button>
                </div>

                {pinError && (
                  <p className="text-[11px] font-semibold text-rose-500 bg-rose-500/10 border border-rose-500/25 p-2.5 rounded-xl animate-pulse">
                    {pinError}
                  </p>
                )}

                <div className="flex gap-2.5 pt-2">
                  <button
                    onClick={() => {
                      setIsPinModalOpen(false);
                      setPinActionCallback(null);
                    }}
                    className={`flex-1 py-3 text-xs font-bold uppercase tracking-wider rounded-2xl border transition-colors cursor-pointer ${
                      dark ? "border-slate-800 text-slate-400 hover:bg-slate-800" : "border-slate-200 text-slate-500 hover:bg-slate-100"
                    }`}
                  >
                    Cancel
                  </button>
                  <button
                    onClick={() => {
                      if (enteredPin.length < 4) {
                        setPinError("Please enter your complete 4-digit PIN.");
                        return;
                      }
                      if (enteredPin !== user.pin) {
                        setPinError("Security clearance error: Transaction PIN invalid.");
                        return;
                      }
                      setIsPinModalOpen(false);
                      if (pinActionCallback) {
                        pinActionCallback();
                      }
                      setPinActionCallback(null);
                    }}
                    className="flex-1 py-3 bg-sky-600 hover:bg-sky-500 active:scale-[0.98] text-white font-black text-xs uppercase tracking-wider rounded-2xl transition-all shadow-lg shadow-sky-500/25 cursor-pointer"
                  >
                    Authorize
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
