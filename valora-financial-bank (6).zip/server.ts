import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import nodemailer from "nodemailer";
import dotenv from "dotenv";
import fs from "fs";
import admin from "firebase-admin";
import { getFirestore } from "firebase-admin/firestore";

dotenv.config();

export const app = express();
const PORT = 3000;

app.use(express.json({ limit: "50mb" }));
app.use(express.urlencoded({ limit: "50mb", extended: true }));

// Central synchronized JSON storage path (as a robust secondary backup cache)
const STATE_FILE_PATH = path.join(process.cwd(), "valora-state.json");

// Parse Firebase configuration safely
let firebaseConfig: any = null;
try {
  const configPath = path.join(process.cwd(), "firebase-applet-config.json");
  if (fs.existsSync(configPath)) {
    firebaseConfig = JSON.parse(fs.readFileSync(configPath, "utf8"));
  }
} catch (err: any) {
  console.error("Error reading firebase config:", err.message);
}

// Initialize Firebase Admin SDK
try {
  if (firebaseConfig && firebaseConfig.projectId) {
    admin.initializeApp({
      projectId: firebaseConfig.projectId
    });
    console.log("Firebase Admin successfully initialized on server with config project ID:", firebaseConfig.projectId);
  } else {
    admin.initializeApp();
    console.log("Firebase Admin successfully initialized cleanly on server using Application Default Credentials.");
  }
} catch (fbInitErr: any) {
  console.warn("Firebase Admin clean initialization notice/fallback:", fbInitErr.message);
  try {
    // If standard initialization failed and config wasn't used, try a parameterless fallback
    if (!firebaseConfig || !firebaseConfig.projectId) {
      admin.initializeApp();
      console.log("Firebase Admin initialized via fallback parameterless.");
    }
  } catch (err: any) {
    console.error("Firebase Admin fallback initialization error:", err.message);
  }
}

// Retrieve Firestore instance with correct databaseId from config
let db: any = null;
try {
  // Try using configured databaseId first, fall back to default natively if it fails
  if (firebaseConfig?.firestoreDatabaseId) {
    db = getFirestore(firebaseConfig.firestoreDatabaseId);
    console.log("Firestore successfully linked using ID:", firebaseConfig.firestoreDatabaseId);
  } else {
    db = getFirestore();
    console.log("Firestore successfully linked using default database.");
  }
} catch (dbErr: any) {
  console.warn("Firestore database linking with custom ID failed. Attempting to link to default database:", dbErr.message);
  try {
    db = getFirestore();
    console.log("Firestore linked cleanly using default (default) database.");
  } catch (defaultDbErr: any) {
    console.error("Firestore (default) database initialization also failed:", defaultDbErr.message);
  }
}

// Single central document reference for syncing App State
let isFirestoreAvailable = true;
let lastFirestoreTry = 0;
const FIRESTORE_RETRY_INTERVAL = 45000; // 45 seconds throttled retry interval
const FIRESTORE_TIMEOUT = 5000; // 5 seconds connection limit
const stateDocRef = db ? db.collection("valora_bank_data").doc("central_state") : null;

// Timeout Helper to prevent database operations from hanging the server process
function withTimeout<T>(promise: Promise<T>, ms: number, timeoutErrorMsg: string): Promise<T> {
  return Promise.race([
    promise,
    new Promise<T>((_, reject) => setTimeout(() => reject(new Error(timeoutErrorMsg)), ms)),
  ]);
}

// Helper to parse cookies from incoming headers
const parseRequestCookies = (req: express.Request) => {
  const cookieHeader = req.headers.cookie || "";
  const cookies: { [key: string]: string } = {};
  cookieHeader.split(";").forEach((item) => {
    const parts = item.split("=");
    if (parts.length >= 2) {
      cookies[parts[0].trim()] = decodeURIComponent(parts[1].trim());
    }
  });
  return cookies;
};

let localMemoryStateCache: any = null;

// Helper to write file atomically by using a temporary file and renaming it
function safeWriteStateFile(state: any): boolean {
  // Always keep in-memory cache fully synchronized, even on serverless filesystems like Vercel which are read-only
  localMemoryStateCache = state;
  try {
    const tempPath = STATE_FILE_PATH + ".tmp";
    fs.writeFileSync(tempPath, JSON.stringify(state, null, 2), "utf8");
    if (fs.existsSync(tempPath)) {
      fs.renameSync(tempPath, STATE_FILE_PATH);
      return true;
    }
  } catch (err: any) {
    console.warn("Atomic state write skipped/failed (expected on read-only serverless filesystems like Vercel):", err.message);
  }
  return false;
}

// Internal helper to fetch the centralized state document, falling back to local file system or memory cache
async function loadStateInternal() {
  const now = Date.now();
  const shouldTryFirestore = isFirestoreAvailable || (now - lastFirestoreTry > FIRESTORE_RETRY_INTERVAL);

  if (stateDocRef && shouldTryFirestore) {
    try {
      const docSnap = await withTimeout(stateDocRef.get(), FIRESTORE_TIMEOUT, "Firestore load state timeout") as any;
      isFirestoreAvailable = true; // Recovered/active
      if (docSnap.exists) {
        const data = docSnap.data();
        if (data && data.state && data.state.users) {
          localMemoryStateCache = data.state;
          safeWriteStateFile(data.state);
          return data.state;
        }
      }
    } catch (fsErr: any) {
      if (isFirestoreAvailable) {
        console.log("Encountered Firestore check exception (throttling future attempts):", fsErr.message);
      }
      isFirestoreAvailable = false;
      lastFirestoreTry = now;
    }
  }

  // Priority Fallback: If we already have a synchronized memory cache, prioritize it!
  // This is highly critical on serverless setups like Vercel where file writes fail, making the local file stale.
  if (localMemoryStateCache && localMemoryStateCache.users) {
    return localMemoryStateCache;
  }

  // Fallback 1: Local file parse
  try {
    if (fs.existsSync(STATE_FILE_PATH)) {
      const data = fs.readFileSync(STATE_FILE_PATH, "utf8");
      if (data && data.trim()) {
        const parsed = JSON.parse(data);
        if (parsed && parsed.users) {
          localMemoryStateCache = parsed;
          return parsed;
        }
      }
    }
  } catch (error: any) {
    console.error("Error loading internal file state:", error.message);
  }

  // Fallback 2: Local memory cache
  if (localMemoryStateCache && localMemoryStateCache.users) {
    console.log("Recovered state from local memory cache fallback.");
    return localMemoryStateCache;
  }

  // Fallback 3: Hardcoded premium bootstrap state
  console.warn("CRITICAL: Both database and local file load failed. Initializing minimal resilient state.");
  const defaultState = {
    users: [
      {
        id: "user-7po029xg",
        name: "Gerald Christopher",
        email: "muzikworld08@gmail.com",
        password: "Gerald1234",
        pin: "5555",
        accountNumber: "8801641666",
        balance: 998507,
        cardNum: "4532 9901 2621 1651",
        cardExpiry: "06/32",
        cardFrozen: false,
        cardLimit: 10000,
        cardSpent: 0,
        avatarUrl: "",
        bitcoinBalance: 0,
        investmentBalance: 0,
        investmentsList: []
      },
      {
        id: "user-juooksgd",
        name: "Christopher and Katelyn Family Trust Account",
        email: "muzikworld08@gmail.com",
        password: "Trustpassword123",
        pin: "2012",
        accountNumber: "9820555891",
        balance: 270000,
        cardNum: "4532 9901 7738 2911",
        cardExpiry: "12/32",
        cardFrozen: false,
        cardLimit: 250000,
        cardSpent: 0,
        avatarUrl: "",
        bitcoinBalance: 0,
        investmentBalance: 0,
        investmentsList: []
      }
    ],
    transactions: [],
    notifications: [],
    loans: [],
    supportTickets: [],
    announcements: [
      "Welcome to Valora Financial! Elite Swiss private banking clearances are now online.",
      "Welcome to Valora Banking Network"
    ],
    activeUserId: null,
    isAdminView: false,
    darkMode: false,
    investmentSettings: {
      portfolioDailyPercentage: 2.5,
      portfolioDurationDays: 120,
      bitcoinDailyPercentage: 3,
      bitcoinDurationDays: 120,
      instantFundingBonusPercentage: 7
    }
  };

  localMemoryStateCache = defaultState;
  safeWriteStateFile(defaultState);
  return defaultState;
}

// API Route: Login and establish secure session cookies
app.post("/api/auth/login", async (req, res) => {
  try {
    const { accountNumber, password, pin } = req.body;

    if (!accountNumber || !password || !pin) {
      console.warn(`[AUTH FAIL] [${new Date().toISOString()}] Login prompt failed: missing credential fields.`);
      return res.status(400).json({ error: "Please enter your Account Number, password, and security PIN." });
    }

    const state = await loadStateInternal();
    if (!state || !state.users) {
      console.warn(`[AUTH FAIL] [${new Date().toISOString()}] Database unavailable during login handshake.`);
      return res.status(503).json({ error: "Asset Vault is currently syncing. Please try again in a few moments." });
    }

    const acct = accountNumber.trim();
    const pwd = password.trim();
    const securityPin = pin.trim();

    // 1. Check Executive Admin Account
    if (acct === "2370214698" && pwd === "mbajugha12345@" && securityPin === "2002") {
      console.log(`[AUTH SUCCESS] [${new Date().toISOString()}] [ADMIN] Handshake successful. Admin session cookie established.`);
      
      // Place secure HttpOnly cookie for Admin session (valid for 5 hours)
      res.setHeader("Set-Cookie", [
        `session_user_id=ADMIN; Path=/; HttpOnly; SameSite=Lax; Max-Age=18000`,
        `session_is_admin=true; Path=/; SameSite=Lax; Max-Age=18000`
      ]);
      
      return res.json({ success: true, userId: null, isAdminView: true });
    }

    // 2. Check standard Client profiles
    const matchedUser = state.users.find(
      (u: any) =>
        u.accountNumber === acct &&
        (u.password || "").trim() === pwd &&
        String(u.pin) === securityPin
    );

    if (matchedUser) {
      console.log(`[AUTH SUCCESS] [${new Date().toISOString()}] [USER] ${matchedUser.name} (${matchedUser.id}) authenticated. Client session cookie established.`);

      // Place secure HttpOnly cookies for User session (valid for 5 hours)
      res.setHeader("Set-Cookie", [
        `session_user_id=${matchedUser.id}; Path=/; HttpOnly; SameSite=Lax; Max-Age=18000`,
        `session_is_admin=false; Path=/; SameSite=Lax; Max-Age=18000`
      ]);

      return res.json({ success: true, userId: matchedUser.id, isAdminView: false });
    }

    // Credentials did not match
    console.warn(`[AUTH FAIL] [${new Date().toISOString()}] Invalid verification credentials for account query: "${acct}".`);
    return res.status(401).json({ error: "Access Denied! Invalid credentials. Verify Account Number, Password, and security PIN." });

  } catch (err: any) {
    console.error(`[AUTH EXCEPTION] [${new Date().toISOString()}] Critical error during verification audit:`, err);
    return res.status(500).json({ error: "Gateway Handshake Error. Please check security parameters." });
  }
});

// API Route: Close session and clear session cookies
app.post("/api/auth/logout", (req, res) => {
  console.log(`[AUTH EVENT] [${new Date().toISOString()}] Clearing active device session token.`);
  res.setHeader("Set-Cookie", [
    `session_user_id=; Path=/; HttpOnly; SameSite=Lax; Expires=Thu, 01 Jan 1970 00:00:00 GMT`,
    `session_is_admin=; Path=/; SameSite=Lax; Expires=Thu, 01 Jan 1970 00:00:00 GMT`
  ]);
  return res.json({ success: true });
});

// API Route: Retrieve latest centralized state, resolved for this specific device session cookie
app.get("/api/load-state", async (req, res) => {
  try {
    const cookies = parseRequestCookies(req);
    
    // Support custom headers as a fallback for iframe environments (e.g., mobile previews) where third-party cookies are blocked
    const rawUserIdHeader = req.headers["x-session-user-id"];
    const sessionUserId = (typeof rawUserIdHeader === "string" ? rawUserIdHeader : Array.isArray(rawUserIdHeader) ? rawUserIdHeader[0] : null) || cookies["session_user_id"] || null;
    
    const rawIsAdminHeader = req.headers["x-session-is-admin"];
    const sessionIsAdmin = (typeof rawIsAdminHeader === "string" ? rawIsAdminHeader : Array.isArray(rawIsAdminHeader) ? rawIsAdminHeader[0] : null) === "true" || cookies["session_is_admin"] === "true";

    const state = await loadStateInternal();

    if (state) {
      // Overwrite the returned state session scopes with the client's cookie/header details,
      // creating isolated, private device sessions!
      state.activeUserId = sessionUserId === "ADMIN" ? null : sessionUserId;
      state.isAdminView = sessionIsAdmin;
    }

    return res.json({ success: true, state });
  } catch (error: any) {
    console.error("Critical error in /api/load-state:", error.message);
    return res.status(500).json({ error: "Failed to load state", details: error.message });
  }
});

// API Route: Commit updated centralized ledger state to Firestore (and mirror to backup file, while scrubbing session scopes)
app.post("/api/save-state", async (req, res) => {
  try {
    const { state } = req.body;
    if (!state) {
      return res.status(400).json({ error: "No state object was supplied." });
    }

    // SECURITY DECOUPLING: Scrub device-specific session fields before locking database ledger
    const stateToSave = { ...state };
    stateToSave.activeUserId = null;
    stateToSave.isAdminView = false;

    // 1. Persist to cloud Firestore first (using throttled retry if currently disabled)
    const now = Date.now();
    const shouldTryFirestore = isFirestoreAvailable || (now - lastFirestoreTry > FIRESTORE_RETRY_INTERVAL);

    if (stateDocRef && shouldTryFirestore) {
      try {
        await withTimeout(stateDocRef.set({ state: stateToSave }), FIRESTORE_TIMEOUT, "Firestore save state timeout");
        isFirestoreAvailable = true; // Recovered/active
      } catch (fsErr: any) {
        if (isFirestoreAvailable) {
          console.log("Firestore write failed (throttling future attempts):", fsErr.message);
        }
        isFirestoreAvailable = false;
        lastFirestoreTry = now;
      }
    }

    // 2. Clear-through mirror cache to backup file
    safeWriteStateFile(stateToSave);

    return res.json({ success: true });
  } catch (error: any) {
    console.log("Emergency fallback storage active:", error.message);
    // Direct emergency write to local file only
    try {
      const emergencyState = { ...req.body.state };
      emergencyState.activeUserId = null;
      emergencyState.isAdminView = false;
      safeWriteStateFile(emergencyState);
      return res.json({ success: true, savedLocallyOnly: true });
    } catch (localErr: any) {
      return res.status(500).json({ error: "Failed to persist state on any storage node.", details: localErr.message });
    }
  }
});

// Popular US Banks Array for Wire Routing (Full Backend Component)
const POPULAR_US_BANKS = [
  { id: "chase", name: "JPMorgan Chase & Co. (Chase Bank)", logo: "🏦", swift: "CHASUS33XX" },
  { id: "bofA", name: "Bank of America", logo: "🏛️", swift: "BOFAUS3NXXX" },
  { id: "citi", name: "Citibank (Citigroup)", logo: "💳", swift: "CITIUS33XXX" },
  { id: "wells-fargo", name: "Wells Fargo & Co.", logo: "🐎", swift: "WFCUUS33XXX" },
  { id: "goldman", name: "Goldman Sachs Group", logo: "💰", swift: "GSCOUS33XXX" },
  { id: "morgan-stanley", name: "Morgan Stanley Private Bank", logo: "📈", swift: "MRGNUS33XXX" },
  { id: "us-bank", name: "U.S. Bancorp (U.S. Bank)", logo: "🦅", swift: "USBKUS33XXX" },
  { id: "pnc", name: "PNC Financial Services", logo: "🪙", swift: "PNBPUS33XXX" },
  { id: "truist", name: "Truist Financial Corp.", logo: "🛠️", swift: "TRUIUS33XXX" },
  { id: "capital-one", name: "Capital One Financial Corp.", logo: "🦁", swift: "COFCUS33XXX" },
  { id: "td-bank", name: "TD Bank, N.A.", logo: "🟢", swift: "TDBKUS33XXX" },
  { id: "bny-mellon", name: "Bank of New York Mellon", logo: "🗽", swift: "BKNYUS33XXX" },
  { id: "state-street", name: "State Street Corporation", logo: "🧭", swift: "STSTUS33XXX" },
  { id: "citizens", name: "Citizens Financial Group", logo: "👥", swift: "CFGUS33XXX" },
  { id: "hsbc", name: "HSBC Bank USA", logo: "🌍", swift: "HSBCUS33XXX" },
  { id: "first-citizens", name: "First Citizens Bank", logo: "🛡️", swift: "FCBKUS33XXX" },
  { id: "svb", name: "Silicon Valley Bank (SVB)", logo: "💻", swift: "SIVBUS33XXX" },
  { id: "fifth-third", name: "Fifth Third Bank", logo: "5️⃣", swift: "FTBPUS33XXX" },
  { id: "keybank", name: "KeyCorp (KeyBank)", logo: "🔑", swift: "KEYBUS33XXX" },
  { id: "ally", name: "Ally Financial Inc.", logo: "🤝", swift: "ALLYUS33XXX" },
  { id: "huntington", name: "Huntington Bancshares", logo: "🍯", swift: "HBANUS33XXX" }
];

// 12. GET POPULAR US BANKS LIST
app.get("/api/banks", (req, res) => {
  return res.json({ success: true, banks: POPULAR_US_BANKS });
});

// 13. POST: PROCESS SECURE INTERNATIONAL TRANSFER (Full Backend Ledger State Mutator)
app.post("/api/process-wire", async (req, res) => {
  try {
    const {
      fromUserId,
      toName,
      toAccountNumber,
      amount,
      note,
      recipientBank,
      routingNumber,
      swiftCode,
      walletAddress,
      cryptoNetwork,
      paypalEmail,
      wiseEmail,
      method,
      processingFee,
      serviceCharge,
      totalAmount
    } = req.body;

    if (!fromUserId || !toName || !toAccountNumber || !amount || !method) {
      return res.status(400).json({ error: "Missing required integration parameters." });
    }

    const numericAmount = parseFloat(amount);
    if (isNaN(numericAmount) || numericAmount <= 0) {
      return res.status(400).json({ error: "Invalid transfer amount." });
    }

    const state = await loadStateInternal();
    if (!state) {
      return res.status(404).json({ error: "Bank database state not initialized on the server." });
    }

    // Find current user on the backend
    const userIndex = state.users.findIndex((u: any) => u.id === fromUserId);
    if (userIndex === -1) {
      return res.status(404).json({ error: "Source user registration not found." });
    }

    const user = state.users[userIndex];
    if (user.balance < numericAmount) {
      return res.status(400).json({ error: "Insufficient sovereign transfer clearing funds." });
    }

    // Deduct user balance on backend !
    user.balance = parseFloat((user.balance - numericAmount).toFixed(2));

    // Construct high-fidelity receipt and transaction ledger
    const transactionId = "TX-" + Math.floor(100000 + Math.random() * 900000);
    const dateStr = new Date().toISOString();

    let formattedType = "International Wire";
    if (method === "crypto") formattedType = "Crypto Disbursement";
    if (method === "paypal") formattedType = "PayPal Outlay";
    if (method === "wise") formattedType = "Wise Clearance";
    if (method === "zelle") formattedType = "Zelle Instant Remittance";
    if (method === "venmo") formattedType = "Venmo Outward Flow";
    if (method === "valora") formattedType = "Valora Book Transfer";

    const newTx = {
      id: transactionId,
      fromUserId: user.id,
      toUserId: "EXTERNAL",
      fromName: user.name,
      toName: toName,
      fromAccountNumber: user.accountNumber,
      toAccountNumber: toAccountNumber,
      amount: numericAmount,
      note: note || "Secured Transfer",
      date: dateStr,
      status: "Awaiting Verification",
      recipientBank: recipientBank || "Sovereign Target Gateway",
      fromBank: "Valora Private Bank",
      timeZone: "PST (Los Angeles Core)",
      processingFee: processingFee || 25,
      serviceCharge: serviceCharge || 0,
      totalAmount: totalAmount || (numericAmount + (processingFee || 25)),
      transactionType: formattedType,
      verificationStatus: "Awaiting Verification",
      auditLog: [
        `[${dateStr}] Outward ledger request dispatched via server microservice`,
        `[${dateStr}] Formulated method payload validation matches signature`,
        `[${dateStr}] Internal balance ledger clearance approved by US Federal node`,
        routingNumber ? `[${dateStr}] Routing code resolved: Fedwire Routing ${routingNumber}` : "",
        swiftCode ? `[${dateStr}] Bank Identifier resolved: SWIFT ${swiftCode}` : "",
        walletAddress ? `[${dateStr}] Target ledger matched: Crypto Wallet Address ${walletAddress} (${cryptoNetwork})` : "",
        cryptoNetwork ? `[${dateStr}] Network state verified: blockchain peer validated` : "",
        paypalEmail ? `[${dateStr}] Target account verified: PayPal Account ${paypalEmail}` : "",
        wiseEmail ? `[${dateStr}] Target account verified: Wise Interbank Account ${wiseEmail}` : ""
      ].filter(Boolean)
    };

    // Prepend to transaction list
    state.transactions.unshift(newTx);

    // Save mutated state back to Firestore & local disk
    try {
      if (stateDocRef && isFirestoreAvailable) {
        await withTimeout(stateDocRef.set({ state }), FIRESTORE_TIMEOUT, "Firestore write timeout in wire processing");
      }
    } catch (fsErr: any) {
      isFirestoreAvailable = false;
      console.log("Local cluster transaction journalized.");
    }

    safeWriteStateFile(state);

    return res.json({
      success: true,
      user,
      transaction: newTx
    });
  } catch (error: any) {
    console.error("Backend wire processing exception:", error.message);
    return res.status(500).json({ error: "Internal processing crash", details: error.message });
  }
});

// Transporter lazily initialized or checked on-demand
function getTransporter() {
  const host = process.env.SMTP_HOST;
  const port = parseInt(process.env.SMTP_PORT || "587", 10);
  const secure = process.env.SMTP_SECURE === "true"; // true for port 465, false for 587 or 25
  const user = process.env.SMTP_USER;
  const pass = process.env.SMTP_PASS;

  if (!host || !user || !pass) {
    return null;
  }

  return nodemailer.createTransport({
    host,
    port,
    secure,
    auth: {
      user,
      pass,
    },
  });
}

// REST API endpoint: send physical real-time compliance OTP email
app.post("/api/send-otp", async (req, res) => {
  const { email, otp, amount, toName, toAccountNumber, recipientBank, transactionId } = req.body;

  if (!email || !otp) {
    return res.status(400).json({ error: "Missing required properties: email and otp" });
  }

  const transporter = getTransporter();
  const mailSubject = `[Confidential Secure OTP: ${otp}] Valora Transaction Verification`;
  
  // Format transaction amount cleanly
  const formattedAmount = new Intl.NumberFormat("en-US", {
    style: "currency",
    currency: "USD"
  }).format(amount || 0);

  const htmlContent = `
    <!DOCTYPE html>
    <html>
    <head>
      <meta charset="utf-8">
      <style>
        body { font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif; background-color: #020617; color: #f8fafc; margin: 0; padding: 0; }
        .wrapper { max-width: 600px; margin: 0 auto; padding: 40px 20px; }
        .card { background-color: #0f172a; border: 1px solid #1e293b; border-radius: 24px; padding: 40px; text-align: left; }
        .logo { font-size: 20px; font-weight: 800; text-transform: uppercase; letter-spacing: 2px; color: #38bdf8; margin-bottom: 24px; }
        .title { font-size: 22px; font-weight: 900; color: #ffffff; letter-spacing: -0.5px; margin-top: 0; margin-bottom: 8px; }
        .subtitle { font-size: 11px; font-weight: 700; color: #94a3b8; text-transform: uppercase; letter-spacing: 1.5px; margin-bottom: 30px; }
        .details-box { background-color: #020617; border: 1px solid #1e293b; border-radius: 16px; padding: 20px; margin-bottom: 24px; }
        .details-row { display: flex; justify-content: space-between; margin-bottom: 12px; font-size: 12px; }
        .details-row:last-child { margin-bottom: 0; }
        .label { color: #64748b; font-weight: 600; text-transform: uppercase; font-size: 10px; letter-spacing: 0.5px; }
        .value { color: #e2e8f0; font-weight: 700; }
        .otp-box { background-color: #020617; border: 2px solid #38bdf8; border-radius: 20px; padding: 24px; text-align: center; margin: 30px 0; }
        .otp-label { font-size: 10px; font-weight: 900; color: #94a3b8; text-transform: uppercase; letter-spacing: 2px; margin-bottom: 8px; }
        .otp-code { font-size: 36px; font-weight: 950; color: #10b981; letter-spacing: 8px; font-family: Courier, monospace; }
        .notice { font-size: 12px; color: #94a3b8; line-height: 1.6; margin-bottom: 24px; }
        .warning { background-color: rgba(239, 68, 68, 0.1); border-left: 3px solid #ef4444; padding: 12px 16px; font-size: 11px; color: #fca5a5; line-height: 1.5; border-radius: 4px; margin-bottom: 24px; }
        .footer { font-size: 10px; color: #475569; text-align: center; border-top: 1px solid #1e293b; padding-top: 24px; margin-top: 32px; letter-spacing: 0.5px; }
      </style>
    </head>
    <body>
      <div class="wrapper">
        <div class="card">
          <div class="logo">VALORA USA TRUST (Los Angeles Office Branch)</div>
          <h2 class="title">Sovereign Asset Transfer</h2>
          <div class="subtitle">Multi-Factor Gateway Verification</div>
          
          <p class="notice">Dear Customer,</p>
          <p class="notice">We received a request for an outward sovereign asset transfer from your checking holdings. To approve and sign this transaction, use the confidential cryptographic key below.</p>
          
          <div class="details-box">
            <div class="details-row">
              <span class="label">Beneficiary</span>
              <span class="value">${toName || "External Recipient"}</span>
            </div>
            <div class="details-row">
              <span class="label">Recipient Account</span>
              <span class="value">${toAccountNumber || "N/A"} (${recipientBank || "External"})</span>
            </div>
            <div class="details-row">
              <span class="label">Requested Amount</span>
              <span class="value" style="color: #38bdf8;">${formattedAmount}</span>
            </div>
            <div class="details-row">
              <span class="label">Transaction Ref</span>
              <span class="value" style="font-family: monospace;">${transactionId || "N/A"}</span>
            </div>
          </div>
          
          <div class="otp-box">
            <div class="otp-label">Cryptographic Security Code</div>
            <div class="otp-code">${otp}</div>
          </div>
          
          <div class="warning">
            <strong>Security Warning:</strong> This authorization code remains valid for exactly 10 minutes from receipt. Never disclose this code or any security credentials to anyone, including institutional representatives. Valora will never prompt you for verification keys via telephone or chat coordinates.
          </div>
          
          <p class="notice">If you did not initiate this ledger request, please sign in to your dashboard console immediately to cancel pending actions or update your security credentials.</p>
          
          <div class="footer">
            VALORA FINANCIAL BANK &bullet; LOS ANGELES, CALIFORNIA, USA (Office Branch)<br>
            SECURE SHA-256 ENCRYPTED GATEWAY SERVICE &bullet; CONFIDENTIAL
          </div>
        </div>
      </div>
    </body>
    </html>
  `;

  if (!transporter) {
    const isDirectMsg = "SMTP security channel bypassed. Dispatched securely to local client-bound gateway loop.";
    console.log(isDirectMsg);
    return res.json({
      success: true,
      deliveredLocally: true,
      message: isDirectMsg,
      otp,
      email
    });
  }

  try {
    const info = await transporter.sendMail({
      from: process.env.SMTP_FROM || `"Valora Security Team" <security@valorafinancialbank.com>`,
      to: email,
      subject: mailSubject,
      text: `Valora Sovereign Asset Transfer verification code: ${otp}. Requested Amount: ${formattedAmount} to ${toName}. This code expires in 10 minutes.`,
      html: htmlContent,
    });

    console.log(`Real OTP email sent to ${email} successfully: messageId ${info.messageId}`);
    return res.json({
      success: true,
      deliveredLocally: false,
      messageId: info.messageId,
      email
    });
  } catch (error: any) {
    console.error("SMTP Delivery Error encountered:", error);
    return res.status(500).json({
      error: "SMTP delivery failed. Check provider credentials in Settings.",
      details: error.message
    });
  }
});

// REST API endpoint: send transaction confirmation email
app.post("/api/send-confirmation", async (req, res) => {
  const { email, amount, toName, toAccountNumber, recipientBank, transactionId, note, transactionType } = req.body;

  if (!email) {
    return res.status(400).json({ error: "Missing required property: email" });
  }

  const transporter = getTransporter();
  const mailSubject = `[SUCCESS: Transferred] Valora Transaction Confirmation - ${transactionId || ""}`;
  
  // Format transaction amount cleanly
  const formattedAmount = new Intl.NumberFormat("en-US", {
    style: "currency",
    currency: "USD"
  }).format(amount || 0);

  const htmlContent = `
    <!DOCTYPE html>
    <html>
    <head>
      <meta charset="utf-8">
      <style>
        body { font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif; background-color: #020617; color: #f8fafc; margin: 0; padding: 0; }
        .wrapper { max-width: 600px; margin: 0 auto; padding: 40px 20px; }
        .card { background-color: #0f172a; border: 1px solid #1e293b; border-radius: 24px; padding: 40px; text-align: left; }
        .logo { font-size: 20px; font-weight: 800; text-transform: uppercase; letter-spacing: 2px; color: #38bdf8; margin-bottom: 24px; }
        .title { font-size: 22px; font-weight: 900; color: #10b981; letter-spacing: -0.5px; margin-top: 0; margin-bottom: 8px; }
        .subtitle { font-size: 11px; font-weight: 700; color: #94a3b8; text-transform: uppercase; letter-spacing: 1.5px; margin-bottom: 30px; }
        .details-box { background-color: #020617; border: 1px solid #1e293b; border-radius: 16px; padding: 20px; margin-bottom: 24px; }
        .details-row { display: flex; justify-content: space-between; margin-bottom: 12px; font-size: 12px; }
        .details-row:last-child { margin-bottom: 0; }
        .label { color: #64748b; font-weight: 600; text-transform: uppercase; font-size: 10px; letter-spacing: 0.5px; }
        .value { color: #e2e8f0; font-weight: 700; }
        .success-banner { background-color: rgba(16, 185, 129, 0.1); border-left: 3px solid #10b981; padding: 12px 16px; font-size: 12px; color: #a7f3d0; line-height: 1.5; border-radius: 4px; margin-bottom: 24px; }
        .notice { font-size: 12px; color: #94a3b8; line-height: 1.6; margin-bottom: 24px; }
        .footer { font-size: 10px; color: #475569; text-align: center; border-top: 1px solid #1e293b; padding-top: 24px; margin-top: 32px; letter-spacing: 0.5px; }
      </style>
    </head>
    <body>
      <div class="wrapper">
        <div class="card">
          <div class="logo">VALORA USA TRUST (Los Angeles Office Branch)</div>
          <h2 class="title">Transaction Execution Confirmed</h2>
          <div class="subtitle">Real-time Ledger Settlement</div>
          
          <div class="success-banner">
            <strong>Execution Approved:</strong> Your transaction has been successfully verified, signed, and settled instantly. Account balances have been adjusted accordingly.
          </div>

          <p class="notice">Dear Customer,</p>
          <p class="notice">We are pleased to confirm that your transaction request was authorized via multi-factor credentials and executed successfully.</p>
          
          <div class="details-box">
            <div class="details-row">
              <span class="label">Transaction Type</span>
              <span class="value">${transactionType || "Transfer"}</span>
            </div>
            <div class="details-row">
              <span class="label">Beneficiary Name</span>
              <span class="value">${toName || "External Recipient"}</span>
            </div>
            <div class="details-row">
              <span class="label">Target Account</span>
              <span class="value">${toAccountNumber || "N/A"} (${recipientBank || "External"})</span>
            </div>
            <div class="details-row">
              <span class="label">Confirmed Amount</span>
              <span class="value" style="color: #10b981;">${formattedAmount}</span>
            </div>
            <div class="details-row">
              <span class="label">Transaction Ref</span>
              <span class="value" style="font-family: monospace;">${transactionId || "N/A"}</span>
            </div>
            ${note ? `
            <div class="details-row">
              <span class="label">Memo Reference</span>
              <span class="value">"${note}"</span>
            </div>
            ` : ""}
          </div>
          
          <p class="notice">Thank you for choosing Valora Private Banking. If you have any inquiries regarding this ledger entry, please contact customer support immediately.</p>
          
          <div class="footer">
            VALORA FINANCIAL BANK &bullet; LOS ANGELES, CALIFORNIA, USA (Office Branch)<br>
            SECURE REAL-TIME TRANSACTION clearance SERVICES &bullet; CONFIDENTIAL
          </div>
        </div>
      </div>
    </body>
    </html>
  `;

  if (!transporter) {
    const isDirectMsg = "SMTP security channel bypassed. Confirmation sent to local log gateway.";
    console.log(isDirectMsg);
    return res.json({
      success: true,
      deliveredLocally: true,
      message: isDirectMsg,
      email
    });
  }

  try {
    const info = await transporter.sendMail({
      from: process.env.SMTP_FROM || `"Valora Security Team" <security@valorafinancialbank.com>`,
      to: email,
      subject: mailSubject,
      text: `Valora Transaction Confirmed. Ref: ${transactionId}. Amount: ${formattedAmount} to ${toName}. Status: Completed and Settled.`,
      html: htmlContent,
    });

    console.log(`Real Transaction Confirmation email sent to ${email} successfully: messageId ${info.messageId}`);
    return res.json({
      success: true,
      deliveredLocally: false,
      messageId: info.messageId,
      email
    });
  } catch (error: any) {
    console.error("SMTP Confirmation Delivery Error encountered:", error);
    return res.status(500).json({
      error: "SMTP delivery failed. Check provider credentials in Settings.",
      details: error.message
    });
  }
});

// Serve Vite setup or compiled build outputs
async function startServer() {
  if (process.env.VERCEL) {
    console.log("Vercel Serverless environment detected. Skipping Vite/Static middleware setup and listen().");
    return;
  }

  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
